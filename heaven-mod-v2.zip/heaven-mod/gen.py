import json, os, random, struct, zlib, shutil

ROOT = os.path.dirname(os.path.abspath(__file__))
MOD = "heaven"
RES = ROOT + "/src/main/resources"
ASSETS = RES + "/assets/" + MOD
DATA = RES + "/data/" + MOD
shutil.rmtree(ROOT + "/src/main/resources", ignore_errors=True)

# ---------------------------------------------------------------- helpers
def w(path, content):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        f.write(content if isinstance(content, str) else json.dumps(content, indent=1))

def hexrgb(h):
    h = h.lstrip("#")
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))

def clamp(v): return max(0, min(255, int(v)))
def shade(c, f): return (clamp(c[0] * f), clamp(c[1] * f), clamp(c[2] * f), 255)

def save_png(path, px):
    h = len(px); wd = len(px[0])
    raw = b"".join(b"\x00" + bytes([v for p in row for v in p]) for row in px)
    def chunk(t, d):
        c = struct.pack(">I", len(d)) + t + d
        return c + struct.pack(">I", zlib.crc32(t + d) & 0xffffffff)
    data = b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", wd, h, 8, 6, 0, 0, 0)) \
        + chunk(b"IDAT", zlib.compress(raw)) + chunk(b"IEND", b"")
    os.makedirs(os.path.dirname(path), exist_ok=True)
    open(path, "wb").write(data)

def canvas(wd, h, c=(0, 0, 0, 0)): return [[c for _ in range(wd)] for _ in range(h)]

def noise_tex(c, var=0.12, seed=0, size=16):
    r = random.Random(seed)
    return [[shade(c, 1 + r.uniform(-var, var)) for _ in range(size)] for _ in range(size)]

def title(n): return " ".join(p.capitalize() for p in n.split("_"))

# ---------------------------------------------------------------- block textures
def tex_bricks(c, seed):
    t = noise_tex(c, 0.06, seed)
    for y in range(16):
        for x in range(16):
            row = y // 4
            if y % 4 == 3 or x % 8 == (0 if row % 2 == 0 else 4):
                t[y][x] = shade(c, 0.7)
    return t

def tex_pillar_side(c, seed):
    t = noise_tex(c, 0.05, seed)
    for y in range(16):
        for x in (0, 1, 7, 8, 14, 15):
            t[y][x] = shade(c, 0.85 if x in (0, 7, 14) else 1.1)
    return t

def tex_pillar_top(c, seed):
    t = noise_tex(c, 0.05, seed)
    for i in range(16):
        for k in (0, 1, 15):
            t[i][k] = shade(c, 0.8); t[k][i] = shade(c, 0.8)
    return t

def tex_log_side(c, seed):
    t = noise_tex(c, 0.08, seed)
    for y in range(16):
        for x in range(0, 16, 3):
            t[y][x] = shade(c, 0.78)
    return t

def tex_log_top(c, seed):
    t = noise_tex(shade(c, 1.1)[:3], 0.04, seed)
    for i in range(16):
        for k in (0, 15):
            t[i][k] = shade(c, 0.7); t[k][i] = shade(c, 0.7)
    for i in range(4, 12):
        for k in (4, 11):
            t[i][k] = shade(c, 0.85); t[k][i] = shade(c, 0.85)
    return t

def tex_planks(c, seed):
    t = noise_tex(c, 0.05, seed)
    for y in range(16):
        for x in range(16):
            if y % 4 == 3: t[y][x] = shade(c, 0.75)
    return t

def tex_leaves(c, seed):
    r = random.Random(seed)
    t = noise_tex(c, 0.18, seed)
    for y in range(16):
        for x in range(16):
            if r.random() < 0.18: t[y][x] = (0, 0, 0, 0)
    return t

def tex_glass(c, seed):
    t = canvas(16, 16, (c[0], c[1], c[2], 90))
    for i in range(16):
        for k in (0, 15):
            t[i][k] = shade(c, 1.1); t[k][i] = shade(c, 1.1)
    for i in range(3, 7): t[i][i] = (255, 255, 255, 200)
    return t

def tex_ore(spot, seed):
    t = noise_tex((205, 214, 230), 0.07, seed)
    r = random.Random(seed + 7)
    for _ in range(7):
        cx, cy = r.randint(2, 13), r.randint(2, 13)
        for dx, dy in ((0, 0), (1, 0), (0, 1), (1, 1)):
            t[min(cy + dy, 15)][min(cx + dx, 15)] = shade(spot, r.uniform(0.9, 1.15))
    return t

def tex_lamp(c, seed):
    t = noise_tex(c, 0.05, seed)
    for y in range(16):
        for x in range(16):
            d = max(abs(x - 7.5), abs(y - 7.5))
            t[y][x] = shade(c, 1.35 - d * 0.04) if d < 6 else shade(c, 0.6)
    return t

def tex_wool(c, seed):
    t = noise_tex(c, 0.08, seed)
    for y in range(0, 16, 2):
        for x in range(0, 16, 2):
            t[y][x] = shade(c, 0.9)
    return t

def tex_flower(c, seed):
    t = canvas(16, 16)
    g = (70, 160, 90, 255)
    for y in range(7, 16): t[y][8] = g; t[y][7] = g
    t[11][9] = g; t[10][10] = g; t[11][6] = g
    for dx, dy in ((-2, 0), (2, 0), (0, -2), (0, 2), (-1, -1), (1, -1), (-1, 1), (1, 1), (0, 0), (-1, 0), (1, 0), (0, -1), (0, 1)):
        x, y = 7 + dx, 5 + dy
        if 0 <= x < 16 and 0 <= y < 16:
            t[y][x] = shade(c, 1.0 if (dx, dy) != (0, 0) else 0.7)
    return t

def tex_grass_top(c, seed): return noise_tex(c, 0.1, seed)
def tex_grass_side(c, dirt, seed):
    t = noise_tex(dirt, 0.1, seed)
    r = random.Random(seed)
    for x in range(16):
        for y in range(r.randint(3, 5)): t[y][x] = shade(c, 1 + r.uniform(-0.1, 0.1))
    return t

# ---------------------------------------------------------------- item icons
def put(t, x, y, c):
    if 0 <= x < 16 and 0 <= y < 16: t[y][x] = c
def rect(t, x0, y0, x1, y1, c):
    for y in range(y0, y1 + 1):
        for x in range(x0, x1 + 1): put(t, x, y, c)
def line(t, x0, y0, x1, y1, c):
    n = max(abs(x1 - x0), abs(y1 - y0), 1)
    for i in range(n + 1):
        put(t, round(x0 + (x1 - x0) * i / n), round(y0 + (y1 - y0) * i / n), c)

HANDLE = (120, 80, 42, 255)
def icon_tool(kind, c):
    t = canvas(16, 16); d = shade(c, 0.7); l = shade(c, 1.25)
    if kind == "sword":
        line(t, 13, 2, 5, 10, c); line(t, 14, 3, 6, 11, d); line(t, 12, 2, 4, 10, l)
        line(t, 3, 8, 7, 12, (230, 200, 90, 255)); line(t, 4, 11, 2, 13, HANDLE); line(t, 5, 12, 3, 14, HANDLE)
    else:
        line(t, 3, 13, 11, 5, HANDLE); line(t, 4, 13, 12, 5, shade(HANDLE[:3], 0.8))
        if kind == "pickaxe":
            line(t, 4, 6, 8, 2, c); line(t, 8, 2, 13, 3, c); line(t, 13, 3, 14, 8, c)
            line(t, 5, 7, 8, 3, d); line(t, 9, 3, 13, 4, d)
        elif kind == "axe":
            rect(t, 8, 2, 13, 7, c); rect(t, 12, 3, 13, 8, d); rect(t, 8, 2, 9, 3, l)
        elif kind == "shovel":
            rect(t, 10, 1, 13, 5, c); rect(t, 11, 6, 12, 6, c); rect(t, 12, 1, 13, 5, d)
        elif kind == "hoe":
            rect(t, 8, 3, 13, 4, c); rect(t, 8, 5, 9, 6, d); rect(t, 12, 3, 13, 4, l)
    return t

def icon_armor(kind, c):
    t = canvas(16, 16); d = shade(c, 0.7); l = shade(c, 1.25)
    if kind == "helmet":
        rect(t, 3, 4, 12, 7, c); rect(t, 3, 8, 5, 12, c); rect(t, 10, 8, 12, 12, c); rect(t, 3, 4, 12, 4, l); rect(t, 5, 6, 10, 7, d)
    elif kind == "chestplate":
        rect(t, 4, 3, 11, 13, c); rect(t, 1, 3, 3, 8, c); rect(t, 12, 3, 14, 8, c)
        rect(t, 6, 3, 9, 4, (0, 0, 0, 0)); rect(t, 4, 10, 11, 13, d); rect(t, 4, 3, 5, 9, l)
    elif kind == "leggings":
        rect(t, 3, 3, 12, 7, c); rect(t, 3, 8, 6, 14, c); rect(t, 9, 8, 12, 14, c); rect(t, 3, 3, 12, 4, l); rect(t, 5, 8, 6, 14, d)
    else:
        rect(t, 3, 8, 6, 13, c); rect(t, 9, 8, 12, 13, c); rect(t, 2, 12, 6, 14, d); rect(t, 9, 12, 13, 14, d); rect(t, 3, 8, 4, 10, l)
    return t

def icon_misc(kind, c, seed=0):
    t = canvas(16, 16); d = shade(c, 0.7); l = shade(c, 1.3)
    r = random.Random(seed)
    if kind == "ingot":
        rect(t, 3, 7, 12, 11, c); rect(t, 4, 5, 13, 8, l); rect(t, 3, 11, 12, 11, d); rect(t, 12, 8, 13, 9, d)
    elif kind == "gem":
        for i, (x0, x1) in enumerate([(6, 9), (5, 10), (4, 11), (4, 11), (5, 10), (6, 9), (7, 8)]):
            rect(t, x0, 3 + i, x1, 3 + i, c)
        rect(t, 5, 4, 6, 6, l); rect(t, 9, 7, 10, 8, d)
    elif kind == "dust":
        for _ in range(26): put(t, r.randint(3, 12), r.randint(8, 13), shade(c, r.uniform(0.85, 1.2)))
    elif kind == "nugget":
        rect(t, 6, 6, 9, 9, c); rect(t, 6, 6, 7, 7, l); rect(t, 9, 9, 9, 9, d)
    elif kind == "food":
        for y in range(16):
            for x in range(16):
                if (x - 7.5) ** 2 + (y - 8.5) ** 2 < 24: put(t, x, y, shade(c, 1 + r.uniform(-0.08, 0.08)))
        rect(t, 5, 6, 6, 7, l); rect(t, 7, 1, 7, 3, HANDLE); rect(t, 8, 2, 10, 3, (90, 180, 90, 255))
    elif kind == "key":
        rect(t, 3, 3, 6, 6, c); rect(t, 4, 4, 5, 5, (0, 0, 0, 0)); line(t, 6, 6, 13, 13, c); line(t, 7, 6, 14, 13, d)
        rect(t, 11, 11, 13, 11, l); rect(t, 12, 13, 14, 13, l)
    else:  # misc orb/charm
        for y in range(16):
            for x in range(16):
                if (x - 7.5) ** 2 + (y - 7.5) ** 2 < 20: put(t, x, y, shade(c, 1.2 - ((x - 7.5) ** 2 + (y - 7.5) ** 2) / 40))
        rect(t, 5, 4, 6, 5, (255, 255, 255, 220))
    return t


# ================================================================ v2 TEXTURE ENGINE
import math, zlib
_raw_save_png = save_png

def _norm(px): return [[(p + (255,)) if len(p) == 3 else p for p in r] for r in px]

def _outline_icon(px):
    px = _norm(px)
    h = len(px); wd = len(px[0]); out = [r[:] for r in px]
    for y in range(h):
        for x in range(wd):
            c = px[y][x]
            if c[3] == 0:
                for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                    nx, ny = x + dx, y + dy
                    if 0 <= nx < wd and 0 <= ny < h and px[ny][nx][3] > 0:
                        n = px[ny][nx]; out[y][x] = (clamp(n[0] * .32), clamp(n[1] * .32), clamp(n[2] * .38), 255); break
            else:
                up = y == 0 or px[y - 1][x][3] == 0; lf = x == 0 or px[y][x - 1][3] == 0
                dn = y == h - 1 or px[y + 1][x][3] == 0; rt = x == wd - 1 or px[y][x + 1][3] == 0
                f = 1.0
                if up or lf: f *= 1.22
                if dn or rt: f *= .8
                out[y][x] = (clamp(c[0] * f), clamp(c[1] * f), clamp(c[2] * f), c[3])
    return out

def _detail_block(px, path):
    b = os.path.basename(path)
    if not (b.endswith("_block.png") or b.endswith("_ore.png")): return px
    if any(p[3] < 255 for r in px for p in r): return px
    rng = random.Random(len(b) * 7 + ord(b[0])); out = [r[:] for r in px]
    for y in range(16):
        for x in range(16):
            c = px[y][x]; f = 1.0
            if y == 0 or x == 0: f = 1.1
            if y == 15 or x == 15: f = .88
            if rng.random() < .05: f *= rng.choice((.85, 1.15))
            out[y][x] = (clamp(c[0] * f), clamp(c[1] * f), clamp(c[2] * f), 255)
    return out

def save_png(path, px):
    if "/textures/item/" in path and len(px) == 16: px = _outline_icon(px)
    elif "/textures/block/" in path and len(px) == 16: px = _detail_block(px, path)
    _raw_save_png(path, _norm(px))

_orig_icon_armor = icon_armor
def icon_armor(kind, c):
    t = _orig_icon_armor(kind, c); L = shade(c, 1.5); GL = (255, 240, 140, 255)
    if kind == "helmet":
        rect(t, 5, 8, 10, 9, (30, 26, 44, 255)); put(t, 6, 8, (255, 255, 200, 255)); put(t, 9, 8, (255, 255, 200, 255)); rect(t, 7, 4, 8, 6, L)
    elif kind == "chestplate":
        rect(t, 7, 6, 8, 7, GL); put(t, 7, 6, (255, 255, 255, 255)); rect(t, 4, 12, 11, 12, shade(c, .6))
    elif kind == "leggings":
        rect(t, 3, 5, 12, 5, GL); put(t, 7, 5, (255, 120, 120, 255)); rect(t, 3, 10, 6, 10, shade(c, .6)); rect(t, 9, 10, 12, 10, shade(c, .6))
    else:
        rect(t, 3, 9, 6, 9, L); rect(t, 9, 9, 12, 9, L); rect(t, 2, 13, 6, 13, shade(c, .55)); rect(t, 9, 13, 13, 13, shade(c, .55))
    return t

def _mixc(a, b, t): return tuple(clamp(a[i] * (1 - t) + b[i] * t) for i in range(3))
FS = dict(up=1.18, north=1.0, east=.9, west=.9, south=.82, down=.68)
def _faces(x, y, ix, iy, iz):
    return {"up": (x + iz, y, ix, iz), "down": (x + iz + ix, y, ix, iz), "east": (x, y + iz, iz, iy), "north": (x + iz, y + iz, ix, iy),
            "west": (x + iz + ix, y + iz, iz, iy), "south": (x + 2 * iz + ix, y + iz, ix, iy)}
def _i(v): return int(math.ceil(v - 1e-6))

def _pc(role, bn, face, fx, fy, fw, fh, base, acc, hostile, seed, pat):
    if role == "eye":
        if face == "north":
            if fx == fw - 1 and fy == fh - 1: return (25, 15, 40, 255)
            return (255, 70, 55, 255) if hostile else (255, 246, 205, 255)
        return (255, 220, 140, 255)
    f = FS[face]
    h = (fx * 73856093 ^ fy * 19349663 ^ (ord(face[0]) * 83492791) ^ seed) & 0xffff
    nz = 1 + ((h % 100) - 50) / 900.0
    border = (fx == 0 or fy == 0 or fx == fw - 1 or fy == fh - 1) and fw > 3 and fh > 3
    c = base
    if role == "acc":
        if bn.startswith("wing"):
            t = fx / max(fw - 1, 1); c = _mixc(base, acc, .55 + .45 * t)
            if fx % 3 == 0: f *= .86
            if fx >= fw - 2: c = _mixc(c, (255, 255, 255), .35)
        elif bn.startswith("orb"):
            dx, dy = (fx + .5) / fw - .5, (fy + .5) / fh - .5
            c = _mixc(acc, (255, 255, 255), max(0, 1 - 2.2 * (dx * dx + dy * dy) ** .5)); f = 1.1
        elif bn == "shell":
            c = acc if ((fx // 3 + fy // 3) % 2 == 0) else _mixc(acc, (0, 0, 0), .25)
        elif bn == "tail":
            c = _mixc(acc, (255, 255, 255), .3) if ((fx + fy) // 2) % 2 == 0 else acc
        else:
            t = 1 - fy / max(fh - 1, 1); c = _mixc(acc, (255, 248, 230), t * .55)
    else:
        if bn in ("head", "core"):
            if face == "up" and fx == fw // 2: c = acc
            elif face == "north":
                if fy == int(fh * .72) and abs(fx - fw / 2 + .5) < 1.6: c = _mixc(base, (0, 0, 0), .6)
                elif fy == int(fh * .72) + 1 and hostile and fx in (fw // 2 - 2, fw // 2 + 1): c = (255, 255, 255)
                elif fy == int(fh * .22) and 1 < fx < fw - 2: c = _mixc(base, (0, 0, 0), .45)
                elif fy == int(fh * .6) and fx in (1, fw - 2): c = _mixc(base, acc, .6)
                elif fy == int(fh * .5) and abs(fx - fw / 2 + .5) < .6: c = _mixc(base, (0, 0, 0), .5)
                else: c = _mixc(base, (255, 255, 255), .12 * (1 - fy / fh))
            elif face in ("east", "west") and fy > fh * .55: c = _mixc(base, acc, .25)
        elif bn.startswith("leg") or bn.startswith("arm"):
            if fy >= fh * .7 and face != "up": c = _mixc(base, acc, .55); f *= .92
            elif face == "north" and fy < 2: c = _mixc(base, acc, .25)
        elif bn.startswith("seg"):
            c = _mixc(base, acc, .35) if ((fx + fy) % 4 < 2) else base
            if face == "down": c = _mixc(base, (255, 255, 255), .5)
        else:
            if pat == 0: c = _mixc(base, acc, .4) if (fy // 2) % 2 == 0 else base
            elif pat == 1: c = acc if h % 9 == 0 else base
            elif pat == 2: c = _mixc(base, acc, fy / max(fh - 1, 1) * .75)
            else:
                if face in ("north", "down"): c = _mixc(base, (255, 255, 255), .45)
                elif face == "up": c = _mixc(base, acc, .3)
    if border: f *= .82
    if face in ("east", "west", "north", "south") and fy >= fh - 1: f *= .85
    f *= nz
    return (clamp(c[0] * f), clamp(c[1] * f), clamp(c[2] * f), 255)

def pack_and_paint(bones, base_hex, acc_hex, hostile, seed):
    base, acc, pat = hexrgb(base_hex), hexrgb(acc_hex), seed % 4
    items = []
    for b in bones:
        for c in b["cubes"]:
            sx, sy, sz = c["size"]
            role = "eye" if c["uv"] == EYE else ("acc" if c["uv"] == [32, 0] else "base")
            items.append((b["name"], c, role, 2 * (_i(sx) + _i(sz)), _i(sz) + _i(sy), _i(sx), _i(sy), _i(sz)))
    img = [[(0, 0, 0, 0) for _ in range(128)] for _ in range(128)]
    x = y = rowh = 0
    for it in sorted(items, key=lambda t: -t[4]):
        bn_, c, role, W, H, ix, iy, iz = it
        if x + W > 128: x, y, rowh = 0, y + rowh, 0
        assert y + H <= 128, "atlas overflow"
        c["uv"] = [x, y]
        for face, (rx, ry, rw, rh) in _faces(x, y, ix, iy, iz).items():
            for fy in range(rh):
                for fx in range(rw):
                    img[ry + fy][rx + fx] = _pc(role, bn_, face, fx, fy, rw, rh, base, acc, hostile, seed, pat)
        x += W; rowh = max(rowh, H)
    return img

ARM_STYLE = dict(feather="feather", pearl="beads", halo_gold="plates", sunstone="rays", celestial="stars", seraphite="wings", divinium="runes")
ARM_TRIM = dict(feather="#9cc8ff", pearl="#c9a8ff", halo_gold="#fff3b0", sunstone="#ff6a2e", celestial="#ffffff", seraphite="#ffd34d", divinium="#7be3ff")
ARM_GEM = dict(feather="#7be3c8", pearl="#ff9fd0", halo_gold="#7be3ff", sunstone="#ff4040", celestial="#fff08a", seraphite="#7be3ff", divinium="#ff5fe0")

def _armor_px(style, part, face, fx, fy, fw, fh, layer, c, trim, gem):
    f = FS[face]; v = list(c)
    if style == "plates":
        if fx % 4 == 0 or fy % 4 == 0: f *= .8
        elif fx % 4 == 1 and fy % 4 == 1: f *= 1.25
    elif style == "feather":
        xx = (fx + ((fy // 3) % 2) * 2) % 4
        if xx == 0: f *= .78
        elif xx == 1 and fy % 3 == 0: f *= 1.2
    elif style == "beads":
        cx, cy = fx % 3, fy % 3
        if cx == 1 and cy == 1: f *= 1.4
        elif cx == 0 or cy == 0: f *= .82
    elif style == "rays":
        band = int((math.atan2(fy - fh / 2, fx - fw / 2) + math.pi) / (math.pi / 6)) % 2
        f *= 1.15 if band else .88
    elif style == "stars":
        f *= .72; hh = (fx * 31 + fy * 17 + len(part) * 7) % 23
        if hh == 0: v = [255, 255, 255]; f = 1
        elif hh == 11: v = list(trim); f = 1
    elif style == "wings":
        k = (fx + fy // 2) % 5
        if k == 0: f *= .8
        elif k == 4: f *= 1.15
        if fy % 6 == 5: v = list(trim); f = .95
    elif style == "runes":
        f *= .85
        if fx % 4 == 0 or fy % 4 == 0: f *= .8
        if ((fx // 2) * 5 + (fy // 2) * 3 + len(part)) % 7 in (0, 1) and fx % 2 == 0 and fx % 4: v = [min(255, t + 60) for t in trim]; f = 1.0
    if part == "head" and face == "north":
        if fy in (3, 4) and 0 < fx < fw - 1: v = [22, 20, 34]; f = 1
        if fy == 3 and fx in (2, 5): v = list(trim); f = 1.1
        if fy == 2: v = list(trim); f = .95
    if part == "head" and face == "up" and fx in (3, 4): v = list(trim); f = 1
    if part == "body":
        if layer == 1:
            if fy == 0: v = list(trim); f = .95
            if face == "north" and fx in (3, 4) and fy in (2, 3): v = list(gem); f = 1.1 if fy == 2 else .8
            if fy == 10: v = list(trim); f = .85
        else:
            if fy < 3: v = list(trim); f = .9
            if face == "north" and fx in (3, 4) and fy == 1: v = list(gem); f = 1.1
    if part == "arm":
        if fy < 3 and fy != 2: v = list(trim); f = .95
        if fy >= fh - 2: v = list(trim); f = .85
    if part == "leg":
        if layer == 1:
            if fy >= fh - 3: v = list(trim) if fy == fh - 3 else [q * .55 for q in c]; f = 1
        else:
            if fy < 2: v = list(trim); f = .9
            if fy in (5, 6): v = list(trim); f = .88
    if fw > 3 and fh > 3 and (fx == 0 or fy == 0 or fx == fw - 1 or fy == fh - 1): f *= .8
    return (clamp(v[0] * f), clamp(v[1] * f), clamp(v[2] * f), 255)

def paint_armor(m, layer, c):
    st, trim, gem = ARM_STYLE[m], hexrgb(ARM_TRIM[m]), hexrgb(ARM_GEM[m])
    img = [[(0, 0, 0, 0) for _ in range(64)] for _ in range(32)]
    boxes = [("body", 16, 16, 8, 12, 4), ("leg", 0, 16, 4, 12, 4)] if layer == 2 else \
        [("head", 0, 0, 8, 8, 8), ("body", 16, 16, 8, 12, 4), ("arm", 40, 16, 4, 12, 4), ("leg", 0, 16, 4, 12, 4)]
    for part, x, y, ix, iy, iz in boxes:
        for face, (rx, ry, rw, rh) in _faces(x, y, ix, iy, iz).items():
            for fy in range(rh):
                for fx in range(rw):
                    img[ry + fy][rx + fx] = _armor_px(st, part, face, fx, fy, rw, rh, layer, c, trim, gem)
    return img

WORKFLOW = """name: Build jar
on:
  push:
  workflow_dispatch:
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: 21
      - uses: gradle/actions/setup-gradle@v4
        with:
          gradle-version: 8.10.2
      - name: Unzip project
        run: unzip -q heaven-mod-v2.zip
      - name: Build
        run: cd heaven-mod && gradle build --no-daemon
      - uses: actions/upload-artifact@v4
        with:
          name: heaven-dimension-jar
          path: heaven-mod/build/libs/heaven-dimension-1.0.0.jar
"""
w(ROOT + "/.github/workflows/build.yml", WORKFLOW.replace("      - name: Unzip project\n        run: unzip -q heaven-mod-v2.zip\n", "").replace("cd heaven-mod && gradle", "gradle").replace("heaven-mod/build", "build"))
# ================================================================

# ---------------------------------------------------------------- registries of definitions
BLOCKS, ITEMS, LANG, TAGS = [], [], {}, {"pickaxe": [], "axe": [], "hoe": [], "logs": [], "leaves": [], "dirt": []}
RECIPES, LOOT = {}, {}

def B(name, kind, hard=2.0, res=6.0, sound="stone", light=0, tool="pickaxe", **kw):
    d = dict(name=name, kind=kind, hardness=hard, resistance=res, sound=sound, light=light, tool=tool); d.update(kw)
    BLOCKS.append(d); LANG["block." + MOD + "." + name] = title(name)
    if tool in TAGS: TAGS[tool].append(name)
    return d

def item_model(name, parent, tex=None):
    m = {"parent": parent}
    if tex: m["textures"] = {"layer0": MOD + ":item/" + tex}
    w(ASSETS + "/models/item/" + name + ".json", m)

def I(name, kind, **kw):
    d = dict(name=name, kind=kind); d.update(kw); ITEMS.append(d); LANG["item." + MOD + "." + name] = title(name); return d

def loot_self(name, item=None, count=None, slab=False):
    entry = {"type": "minecraft:item", "name": MOD + ":" + (item or name)}
    if slab:
        entry["functions"] = [{"function": "minecraft:set_count", "count": 2, "add": False,
            "conditions": [{"condition": "minecraft:block_state_property", "block": MOD + ":" + name, "properties": {"type": "double"}}]}]
    LOOT[name] = {"type": "minecraft:block", "pools": [{"rolls": 1, "entries": [entry],
        "conditions": [{"condition": "minecraft:survives_explosion"}]}]}

def blockstate(name, variants): w(ASSETS + "/blockstates/" + name + ".json", {"variants": variants})

def make_cube(name, tex, seedtex=None, parent="minecraft:block/cube_all"):
    blockstate(name, {"": {"model": MOD + ":block/" + name}})
    w(ASSETS + "/models/block/" + name + ".json", {"parent": parent, "textures": {"all": MOD + ":block/" + tex}})
    item_model(name, MOD + ":block/" + name)

def make_stairs(name, tex):
    v = {}
    bot_r = {"east": 0, "west": 180, "south": 90, "north": 270}
    bot_l = {"east": 270, "west": 90, "south": 0, "north": 180}
    top_r = {"east": 90, "west": 270, "south": 180, "north": 0}
    for half in ("bottom", "top"):
        for shape in ("straight", "inner_left", "inner_right", "outer_left", "outer_right"):
            for f in ("east", "west", "south", "north"):
                if half == "bottom": y = (bot_l if shape.endswith("left") else bot_r)[f]
                else: y = (top_r if shape.endswith("right") else bot_r)[f]
                model = name + ("" if shape == "straight" else ("_inner" if shape.startswith("inner") else "_outer"))
                e = {"model": MOD + ":block/" + model, "uvlock": True}
                if half == "top": e["x"] = 180
                if y: e["y"] = y
                v["facing=%s,half=%s,shape=%s" % (f, half, shape)] = e
    blockstate(name, v)
    t = {"bottom": MOD + ":block/" + tex, "top": MOD + ":block/" + tex, "side": MOD + ":block/" + tex}
    for suf, par in (("", "stairs"), ("_inner", "inner_stairs"), ("_outer", "outer_stairs")):
        w(ASSETS + "/models/block/" + name + suf + ".json", {"parent": "minecraft:block/" + par, "textures": t})
    item_model(name, MOD + ":block/" + name)

def make_slab(name, tex, full):
    blockstate(name, {"type=bottom": {"model": MOD + ":block/" + name}, "type=top": {"model": MOD + ":block/" + name + "_top"},
                      "type=double": {"model": MOD + ":block/" + full}})
    t = {"bottom": MOD + ":block/" + tex, "top": MOD + ":block/" + tex, "side": MOD + ":block/" + tex}
    w(ASSETS + "/models/block/" + name + ".json", {"parent": "minecraft:block/slab", "textures": t})
    w(ASSETS + "/models/block/" + name + "_top.json", {"parent": "minecraft:block/slab_top", "textures": t})
    item_model(name, MOD + ":block/" + name)

def make_column(name, side, end, state_axis=True):
    blockstate(name, {"axis=y": {"model": MOD + ":block/" + name}, "axis=z": {"model": MOD + ":block/" + name, "x": 90},
                      "axis=x": {"model": MOD + ":block/" + name, "x": 90, "y": 90}})
    w(ASSETS + "/models/block/" + name + ".json", {"parent": "minecraft:block/cube_column",
        "textures": {"end": MOD + ":block/" + end, "side": MOD + ":block/" + side}})
    item_model(name, MOD + ":block/" + name)

def tex_save(name, px): save_png(ASSETS + "/textures/block/" + name + ".png", px)

def recipe_shaped(name, pattern, key, result, count=1):
    RECIPES[name] = {"type": "minecraft:crafting_shaped", "pattern": pattern,
        "key": {k: {"item": v} for k, v in key.items()}, "result": {"id": result, "count": count}}
def recipe_shapeless(name, ings, result, count=1):
    RECIPES[name] = {"type": "minecraft:crafting_shapeless", "ingredients": [{"item": i} for i in ings],
                     "result": {"id": result, "count": count}}

# ---------------------------------------------------------------- BLOCK CONTENT
seed = 1
# base terrain
B("cloud_stone", "cube", 1.5, 6, "stone"); tex_save("cloud_stone", noise_tex(hexrgb("#e8edf7"), 0.07, 11)); make_cube("cloud_stone", "cloud_stone"); loot_self("cloud_stone")
B("cloud_dirt", "cube", 0.5, 0.5, "grass", tool="shovel"); tex_save("cloud_dirt", noise_tex(hexrgb("#d8cfc0"), 0.1, 12)); make_cube("cloud_dirt", "cloud_dirt"); loot_self("cloud_dirt"); TAGS["dirt"].append("cloud_dirt")
B("cloud_grass", "cube", 0.6, 0.6, "grass", tool="shovel")
tex_save("cloud_grass_top", tex_grass_top(hexrgb("#bfeec9"), 13)); tex_save("cloud_grass_side", tex_grass_side(hexrgb("#bfeec9"), hexrgb("#d8cfc0"), 14))
blockstate("cloud_grass", {"": {"model": MOD + ":block/cloud_grass"}})
w(ASSETS + "/models/block/cloud_grass.json", {"parent": "minecraft:block/cube_bottom_top", "textures": {
    "top": MOD + ":block/cloud_grass_top", "side": MOD + ":block/cloud_grass_side", "bottom": MOD + ":block/cloud_dirt"}})
item_model("cloud_grass", MOD + ":block/cloud_grass"); loot_self("cloud_grass", "cloud_dirt"); TAGS["dirt"].append("cloud_grass")
B("cloud_block", "cube", 0.4, 0.4, "wool", tool="hoe"); tex_save("cloud_block", noise_tex(hexrgb("#ffffff"), 0.04, 15)); make_cube("cloud_block", "cloud_block"); loot_self("cloud_block")

# 28 decorative materials: block / bricks / stairs / slab (+ pillar for first 12)
MATS = dict(pearl="#f2eee6", halo="#ffe9a8", aurora="#7be3c8", sunstone="#ffb347", moonstone="#c9d4f2", celestial="#8fb8ff",
    radiant="#fff3c4", opal="#d6b3ff", ivory="#f6f0dc", gilded="#e8c34a", seraph="#f0f4ff", dawn="#ffc0a8", dusk="#b28fd6",
    amber="#e89a2b", azure="#4fa3ff", rose="#ff9fb5", lumen="#fff08a", ether="#a8f0ff", zephyr="#bfe9d9", solar="#ffd23d",
    lunar="#aab4cc", starlight="#cdd6ff", nimbus="#e1e6ef", divine="#fff8d6", harmonic="#c7e8b0", mirage="#e6c2ff",
    crystal="#bff3ff", serene="#d9f2ff")
for i, (m, hx) in enumerate(MATS.items()):
    c = hexrgb(hx); seed += 3
    n = m + "_block"; B(n, "cube", 2, 6); tex_save(n, noise_tex(c, 0.08, seed)); make_cube(n, n); loot_self(n)
    n2 = m + "_bricks"; B(n2, "cube", 2, 6); tex_save(n2, tex_bricks(c, seed + 1)); make_cube(n2, n2); loot_self(n2)
    n3 = m + "_stairs"; B(n3, "stairs", 2, 6, base=n); make_stairs(n3, n); loot_self(n3)
    n4 = m + "_slab"; B(n4, "slab", 2, 6); make_slab(n4, n, n); loot_self(n4, slab=True)
    recipe_shaped(n3, ["X  ", "XX ", "XXX"], {"X": MOD + ":" + n}, MOD + ":" + n3, 4)
    recipe_shaped(n4, ["XXX"], {"X": MOD + ":" + n}, MOD + ":" + n4, 6)
    recipe_shaped(n2, ["XX", "XX"], {"X": MOD + ":" + n}, MOD + ":" + n2, 4)
    if i < 12:
        n5 = m + "_pillar"; B(n5, "pillar", 2, 6); tex_save(n5, tex_pillar_side(c, seed + 2)); tex_save(n5 + "_top", tex_pillar_top(c, seed + 4))
        make_column(n5, n5, n5 + "_top"); loot_self(n5)
        recipe_shaped(n5, ["X", "X"], {"X": MOD + ":" + n}, MOD + ":" + n5, 2)

# 6 wood families
WOODS = dict(halo_wood=("#d9caa0", "#f1e3b8", "#ffe08a"), aurora_wood=("#bcd9cf", "#d6f0e6", "#8ee6cf"),
    sun_wood=("#e0b98a", "#f6d3a6", "#ffb86b"), star_wood=("#b9bdd8", "#d9ddf2", "#c9d0ff"),
    pearl_wood=("#e4dfe8", "#f5f2f8", "#f4f0ff"), dawn_wood=("#e2b9bd", "#f6d3d6", "#ffb3c1"))
for wn, (lg, pl, lf) in WOODS.items():
    seed += 5
    n = wn + "_log"; B(n, "pillar", 1.8, 2, "wood", tool="axe"); tex_save(n, tex_log_side(hexrgb(lg), seed)); tex_save(n + "_top", tex_log_top(hexrgb(lg), seed + 1))
    make_column(n, n, n + "_top"); loot_self(n); TAGS["logs"].append(n)
    p = wn + "_planks"; B(p, "cube", 1.8, 3, "wood", tool="axe"); tex_save(p, tex_planks(hexrgb(pl), seed + 2)); make_cube(p, p); loot_self(p)
    l = wn + "_leaves"; B(l, "leaves", 0.2, 0.2, "grass", tool="hoe"); tex_save(l, tex_leaves(hexrgb(lf), seed + 3)); make_cube(l, l, parent="minecraft:block/cube_all"); loot_self(l); TAGS["leaves"].append(l)
    s = wn + "_stairs"; B(s, "stairs", 1.8, 3, "wood", tool="axe", base=p); make_stairs(s, p); loot_self(s)
    sl = wn + "_slab"; B(sl, "slab", 1.8, 3, "wood", tool="axe"); make_slab(sl, p, p); loot_self(sl, slab=True)
    recipe_shapeless(p, [MOD + ":" + n], MOD + ":" + p, 4)
    recipe_shaped(s, ["X  ", "XX ", "XXX"], {"X": MOD + ":" + p}, MOD + ":" + s, 4)
    recipe_shaped(sl, ["XXX"], {"X": MOD + ":" + p}, MOD + ":" + sl, 6)

# gem / ingot materials -> ore, storage block, items
GEMS = dict(sunstone=("gem", "#ffb347"), aurora_crystal=("gem", "#7be3c8"), halo_gold=("ingot", "#ffe066"), pearl_shard=("gem", "#f2eee6"),
    celestial_gem=("gem", "#6fa8ff"), seraphite=("ingot", "#e8f0ff"), lumen_gem=("gem", "#fff08a"), azure_gem=("gem", "#4fa3ff"),
    opal_gem=("gem", "#d6b3ff"), divinium=("ingot", "#fff4b0"))
for m, (kind, hx) in GEMS.items():
    c = hexrgb(hx); seed += 4
    o = m + "_ore"; B(o, "cube", 3, 3); tex_save(o, tex_ore(c, seed)); make_cube(o, o); loot_self(o, m)
    sb = m + "_storage_block"; B(sb, "cube", 4, 8); tex_save(sb, noise_tex(c, 0.07, seed + 1)); make_cube(sb, sb); loot_self(sb)
    I(m, kind); I(m + "_dust", "basic"); I(m + "_nugget", "basic")
    save_png(ASSETS + "/textures/item/" + m + ".png", icon_misc(kind, c, seed))
    save_png(ASSETS + "/textures/item/" + m + "_dust.png", icon_misc("dust", c, seed))
    save_png(ASSETS + "/textures/item/" + m + "_nugget.png", icon_misc("nugget", c, seed))
    for nm in (m, m + "_dust", m + "_nugget"): item_model(nm, "minecraft:item/generated", nm)
    recipe_shaped(sb, ["XXX", "XXX", "XXX"], {"X": MOD + ":" + m}, MOD + ":" + sb)
    recipe_shapeless(m + "_from_block", [MOD + ":" + sb], MOD + ":" + m, 9)
    recipe_shaped(m + "_from_nuggets", ["XXX", "XXX", "XXX"], {"X": MOD + ":" + m + "_nugget"}, MOD + ":" + m)
    recipe_shapeless(m + "_nuggets", [MOD + ":" + m], MOD + ":" + m + "_nugget", 9)
    RECIPES[m + "_smelting"] = {"type": "minecraft:smelting", "ingredient": {"item": MOD + ":" + m + "_dust"},
        "result": {"id": MOD + ":" + m}, "experience": 0.7, "cookingtime": 200}

# glass + wool (16 colours)
DYES = dict(white="#ffffff", orange="#f9801d", magenta="#c74ebd", light_blue="#3ab3da", yellow="#fed83d", lime="#80c71f", pink="#f38baa",
    gray="#474f52", light_gray="#9d9d97", cyan="#169c9c", purple="#8932b8", blue="#3c44aa", brown="#835432", green="#5e7c16",
    red="#b02e26", black="#1d1d21")
for d, hx in DYES.items():
    c = hexrgb(hx); seed += 2
    g = "cloud_glass_" + d; B(g, "glass", 0.3, 0.3, "glass", tool="pickaxe"); tex_save(g, tex_glass(c, seed)); make_cube(g, g); loot_self(g)
    wl = "cloud_wool_" + d; B(wl, "cube", 0.5, 0.5, "wool", tool="hoe"); tex_save(wl, tex_wool(c, seed + 1)); make_cube(wl, wl); loot_self(wl)

# lamps
LAMPS = dict(sun_lamp="#ffe36b", moon_lamp="#cfd8ff", star_lantern="#fff3b0", halo_lantern="#ffd966", aurora_lamp="#7bffd0",
    lumen_lamp="#fffa9a", ember_lamp="#ff9d5c", crystal_lamp="#a8f0ff")
for n, hx in LAMPS.items():
    seed += 2; B(n, "cube", 0.8, 1, "glass", light=15 if n != "ember_lamp" else 12); tex_save(n, tex_lamp(hexrgb(hx), seed)); make_cube(n, n); loot_self(n)
    recipe_shaped(n, [" G ", "GDG", " G "], {"G": "minecraft:glass", "D": MOD + ":star_dust"}, MOD + ":" + n)

# flowers (cross)
FLOWERS = dict(sky_lily="#9fd8ff", halo_rose="#ffe066", dawn_tulip="#ffb3a0", star_daisy="#ffffff", aurora_orchid="#7bffd0", sun_poppy="#ff8a3d",
    pearl_bloom="#f5f0ff", azure_bell="#4f8fff", lumen_lotus="#fff08a", zephyr_fern="#a8f0c8", opal_iris="#d6b3ff", gilded_marigold="#e8c34a")
for n, hx in FLOWERS.items():
    seed += 2; B(n, "plant", 0, 0, "grass", tool="hoe"); tex_save(n, tex_flower(hexrgb(hx), seed))
    blockstate(n, {"": {"model": MOD + ":block/" + n}})
    w(ASSETS + "/models/block/" + n + ".json", {"parent": "minecraft:block/cross", "textures": {"cross": MOD + ":block/" + n}})
    item_model(n, "minecraft:item/generated", "../block/" + n) if False else w(ASSETS + "/models/item/" + n + ".json",
        {"parent": "minecraft:item/generated", "textures": {"layer0": MOD + ":block/" + n}})
    loot_self(n)

# ---------------------------------------------------------------- TOOLS
TOOL_MATS = {"halo_gold": dict(level=0, durability=120, speed=12.0, damage=0.0, enchant=22, repair="halo_gold"),
    "sunstone": dict(level=2, durability=500, speed=7.0, damage=2.0, enchant=15, repair="sunstone"),
    "aurora_crystal": dict(level=2, durability=700, speed=8.0, damage=2.5, enchant=16, repair="aurora_crystal"),
    "celestial_gem": dict(level=3, durability=1561, speed=8.0, damage=3.0, enchant=12, repair="celestial_gem"),
    "seraphite": dict(level=3, durability=2000, speed=9.0, damage=3.5, enchant=14, repair="seraphite"),
    "divinium": dict(level=4, durability=2800, speed=10.0, damage=4.5, enchant=18, repair="divinium")}
PATTERNS = dict(sword=["X", "X", "S"], pickaxe=["XXX", " S ", " S "], axe=["XX", "XS", " S"], shovel=["X", "S", "S"], hoe=["XX", " S", " S"])
for m, props in TOOL_MATS.items():
    c = hexrgb(GEMS[m][1])
    for t, pat in PATTERNS.items():
        n = m + "_" + t; I(n, "tool", tool=t, material=m)
        save_png(ASSETS + "/textures/item/" + n + ".png", icon_tool(t, c)); item_model(n, "minecraft:item/handheld", n)
        recipe_shaped(n, pat, {"X": MOD + ":" + m, "S": "minecraft:stick"}, MOD + ":" + n)

# ---------------------------------------------------------------- ARMOR (7 sets x 4 + 3 = 31)
ARM = {"feather": dict(b=1, l=2, c=3, h=1, dur=8, tough=0, kb=0, ench=15, repair="minecraft:feather", hex="#ffffff"),
    "pearl": dict(b=1, l=3, c=4, h=2, dur=12, tough=0, kb=0, ench=18, repair="heaven:pearl_shard", hex="#f2eee6"),
    "halo_gold": dict(b=1, l=3, c=5, h=2, dur=14, tough=0, kb=0, ench=25, repair="heaven:halo_gold", hex="#ffe066"),
    "sunstone": dict(b=2, l=5, c=6, h=2, dur=20, tough=0.5, kb=0, ench=14, repair="heaven:sunstone", hex="#ffb347"),
    "celestial": dict(b=3, l=6, c=8, h=3, dur=34, tough=2, kb=0, ench=12, repair="heaven:celestial_gem", hex="#6fa8ff"),
    "seraphite": dict(b=3, l=6, c=8, h=3, dur=38, tough=2.5, kb=0.05, ench=14, repair="heaven:seraphite", hex="#e8f0ff"),
    "divinium": dict(b=4, l=7, c=9, h=4, dur=46, tough=3, kb=0.1, ench=20, repair="heaven:divinium", hex="#fff4b0")}
APAT = dict(helmet=["XXX", "X X"], chestplate=["X X", "XXX", "XXX"], leggings=["XXX", "X X", "X X"], boots=["X X", "X X"])
for m, a in ARM.items():
    c = hexrgb(a["hex"])
    for layer, size in ((1, (64, 32)), (2, (64, 32))):
        px = paint_armor(m, layer, c)
        save_png(ASSETS + "/textures/models/armor/%s_layer_%d.png" % (m, layer), px)
    for t, pat in APAT.items():
        n = m + "_" + t; I(n, "armor", material=m, slot=t)
        save_png(ASSETS + "/textures/item/" + n + ".png", icon_armor(t, c)); item_model(n, "minecraft:item/generated", n)
        ing = a["repair"]
        recipe_shaped(n, pat, {"X": ing}, MOD + ":" + n)
for n, t, mat, hx in (("halo_crown", "helmet", "divinium", "#fff4b0"), ("angel_wings_chestplate", "chestplate", "seraphite", "#ffffff"),
                      ("cloud_walkers", "boots", "feather", "#e8f4ff")):
    I(n, "armor", material=mat, slot=t)
    save_png(ASSETS + "/textures/item/" + n + ".png", icon_armor(t, hexrgb(hx))); item_model(n, "minecraft:item/generated", n)
    recipe_shaped(n, APAT[t], {"X": ARM[mat]["repair"]}, MOD + ":" + n)

# ---------------------------------------------------------------- FOOD (24)
FOODS = [("ambrosia_apple", 8, 1.2, "minecraft:regeneration", 10, 1, "#ffd24d"), ("nectar_bread", 6, 0.8, None, 0, 0, "#f0d9a8"),
    ("cloud_berry", 2, 0.3, None, 0, 0, "#c9b8ff"), ("honey_cake", 7, 0.6, None, 0, 0, "#ffcf70"), ("angel_cake", 8, 0.8, "minecraft:absorption", 20, 0, "#ffffff"),
    ("pearl_pie", 8, 0.7, None, 0, 0, "#f2eee6"), ("manna", 6, 0.9, "minecraft:strength", 15, 0, "#fff0c4"), ("celestial_stew", 10, 1.0, "minecraft:resistance", 20, 0, "#8fb8ff"),
    ("sun_fruit", 4, 0.4, "minecraft:speed", 15, 0, "#ff9a3d"), ("star_fruit", 4, 0.4, "minecraft:jump_boost", 15, 0, "#fff08a"),
    ("halo_cookie", 3, 0.3, None, 0, 0, "#e8c070"), ("dew_drop_candy", 2, 0.2, None, 0, 0, "#a8f0ff"), ("rainbow_jelly", 5, 0.5, "minecraft:luck", 30, 0, "#ff9ad5"),
    ("golden_pear", 6, 0.8, None, 0, 0, "#e8d04a"), ("seraph_steak", 8, 1.0, None, 0, 0, "#d9a28a"), ("harp_honey", 4, 0.4, None, 0, 0, "#ffb82e"),
    ("ether_tea", 3, 0.3, "minecraft:regeneration", 6, 0, "#bff3ff"), ("lumen_carrot", 5, 0.6, "minecraft:night_vision", 30, 0, "#ffe14d"),
    ("azure_grapes", 3, 0.3, None, 0, 0, "#4f8fff"), ("opal_melon_slice", 3, 0.3, None, 0, 0, "#e6c2ff"), ("zephyr_bread", 5, 0.6, "minecraft:speed", 10, 0, "#d9f0e6"),
    ("nimbus_pudding", 6, 0.6, "minecraft:absorption", 15, 0, "#f4f8ff"), ("dawn_roll", 5, 0.5, None, 0, 0, "#ffc0a8"), ("divine_feast", 12, 1.4, "minecraft:resistance", 40, 1, "#fff8d6")]
for i, (n, nu, sa, ef, du, am, hx) in enumerate(FOODS):
    I(n, "food", nutrition=nu, saturation=sa, effect=ef, duration=du, amplifier=am)
    save_png(ASSETS + "/textures/item/" + n + ".png", icon_misc("food", hexrgb(hx), i)); item_model(n, "minecraft:item/generated", n)

# ---------------------------------------------------------------- MISC (20)
MISC = dict(halo_fragment="#ffe066", feather_bundle="#ffffff", star_dust="#fff3b0", angel_tears="#a8f0ff", light_orb="#fffbd0", golden_harp="#e8c34a",
    sky_compass="#8fb8ff", cloud_bottle="#e8f4ff", wind_charm="#bfe9d9", sun_emblem="#ffb347", moon_emblem="#c9d4f2", seraph_feather="#f0f4ff",
    divine_core="#fff4b0", heaven_scroll="#f6f0dc", gilded_ring="#e8c34a", pearl_necklace="#f2eee6", aurora_prism="#7be3c8", storm_shard="#8fa8ff",
    cherub_arrow="#ffe8c0")
I("cloud_key", "key"); save_png(ASSETS + "/textures/item/cloud_key.png", icon_misc("key", hexrgb("#ffe066"))); item_model("cloud_key", "minecraft:item/generated", "cloud_key")
recipe_shaped("cloud_key", ["FGF", "GDG", "FGF"], {"F": "minecraft:feather", "G": "minecraft:gold_ingot", "D": "minecraft:diamond"}, MOD + ":cloud_key")
for i, (n, hx) in enumerate(MISC.items()):
    I(n, "basic"); save_png(ASSETS + "/textures/item/" + n + ".png", icon_misc("orb" if i % 2 else "gem", hexrgb(hx), i)); item_model(n, "minecraft:item/generated", n)

# ---------------------------------------------------------------- ENTITIES (43) + animations (64)
# name, arch, behavior, flying, hp, speed, dmg, w, h, scale, base, accent, accent_kind, extra_anims
E = [
 ("cloud_sheep","quad","passive",0,10,.22,0,.9,1,1,"#f5f8ff","#cfe3ff","ears",["walk"]),
 ("halo_deer","quad","passive",0,14,.26,0,.9,1.5,1.2,"#f1d9a8","#ffe66b","horns",["walk"]),
 ("sky_rabbit","quad","passive",0,4,.3,0,.4,.5,.6,"#ffffff","#ffd6e8","ears",["walk"]),
 ("angel_fox","quad","passive",0,10,.3,0,.7,.7,.9,"#ffd9a0","#ffffff","tail",["walk"]),
 ("star_cat","quad","passive",0,10,.3,0,.6,.7,.8,"#2b2e55","#ffe45c","tail",["walk"]),
 ("pearl_turtle","quad","passive",0,12,.12,0,1,.5,1,"#e9e4f5","#b9a6e8","shell",[]),
 ("cloud_cow","quad","passive",0,14,.2,0,.9,1.4,1.2,"#ffffff","#bcd7ff","horns",["walk"]),
 ("dawn_boar","quad","passive",0,12,.24,0,.9,.9,1,"#ffb5a0","#fff0d0","horns",[]),
 ("harp_goat","quad","passive",0,12,.25,0,.9,1.2,1,"#f4efe4","#e8c86a","horns",[]),
 ("mist_llama","quad","passive",0,16,.22,0,.9,1.8,1.3,"#e8f4ff","#a8d0ff","ears",[]),
 ("feather_dove","flyer","passive",1,4,.2,0,.4,.4,.7,"#ffffff","#dfe9ff","none",["fly"]),
 ("sun_finch","flyer","passive",1,4,.2,0,.3,.3,.6,"#ffd54a","#ff9a3d","none",["fly"]),
 ("aurora_butterfly","flyer","passive",1,3,.15,0,.3,.3,.6,"#8affd6","#b58cff","none",["fly"]),
 ("cloud_whale","flyer","passive",1,60,.1,0,3,2,3,"#e6f0ff","#9cc4ff","none",[]),
 ("glow_jelly","blob","passive",1,8,.1,0,.8,.9,1,"#ffb3f0","#fff1a8","none",[]),
 ("rainbow_ray","flyer","passive",1,14,.15,0,1.4,.4,1.5,"#7fd1ff","#ff9ad5","none",[]),
 ("star_moth","flyer","passive",1,4,.18,0,.4,.4,.7,"#fff3b0","#c4a8ff","none",[]),
 ("wisp_sprite","blob","passive",1,6,.12,0,.5,.6,.6,"#c8fff4","#ffffff","none",[]),
 ("dawn_swan","flyer","passive",1,8,.2,0,.8,.8,1.2,"#ffffff","#ffc4a8","none",["fly"]),
 ("pegasus","winged_quad","passive",1,22,.3,0,1.2,1.6,1.4,"#ffffff","#ffe08a","ears",["fly"]),
 ("guardian_angel","biped","neutral",0,40,.28,6,.7,2,1.1,"#fff1c2","#ffd34d","halo",["attack"]),
 ("temple_golem","biped","neutral",0,80,.2,10,1.2,2.8,1.5,"#d9d2c0","#b8a46a","none",["attack"]),
 ("sun_lion","quad","neutral",0,30,.3,6,1,1.2,1.3,"#ffc24d","#e07a1f","tail",["attack"]),
 ("storm_ram","quad","neutral",0,24,.28,5,1,1.2,1.2,"#9aa7c4","#e8eefc","horns",[]),
 ("cherub","biped_winged","neutral",1,14,.25,3,.5,1,.6,"#ffe0d0","#ffffff","halo",[]),
 ("lightning_eagle","flyer","neutral",1,18,.3,5,.9,.8,1.3,"#e8d36a","#6aa8ff","none",["fly"]),
 ("fallen_angel","biped_winged","hostile",0,36,.3,7,.7,2,1.1,"#3a3a4d","#8a1c1c","horns",["attack"]),
 ("shadow_wraith","blob","hostile",1,20,.2,5,.8,1.2,1.2,"#2d2540","#7a4cff","none",[]),
 ("thunder_imp","biped","hostile",0,18,.32,4,.5,1,.7,"#6b5cff","#ffe14d","horns",["attack"]),
 ("cloud_serpent","serpent","hostile",0,30,.25,6,.8,.8,1.3,"#cfe6ff","#6aa8ff","horns",["attack"]),
 ("crystal_spider","quad","hostile",0,22,.32,4,1,.7,1.1,"#a8f0ff","#4fa3ff","spikes",[]),
 ("storm_hawk","flyer","hostile",1,16,.32,5,.8,.7,1.2,"#6a7aa0","#d8e4ff","none",[]),
 ("void_seraph","biped_winged","hostile",1,50,.3,8,.8,2.2,1.2,"#1a1a2e","#b36bff","halo",[]),
 ("gale_elemental","blob","hostile",1,26,.25,5,.9,1.2,1.3,"#d8f5f0","#8ae6d8","none",[]),
 ("sky_knight","biped","hostile",0,40,.26,8,.7,2,1.1,"#c9d3e8","#4a63b0","horns",["attack"]),
 ("wrath_golem","biped","hostile",0,100,.2,14,1.6,3.2,1.8,"#a89878","#ff7a2e","spikes",["attack"]),
 ("plague_cherub","biped_winged","hostile",1,20,.28,4,.5,1,.7,"#9cb36a","#4a5a2a","halo",[]),
 ("tempest_wyrm","serpent","hostile",1,70,.3,10,1.2,1.2,1.8,"#5a6fb0","#ffe14d","horns",[]),
 ("pale_harpy","flyer","hostile",1,18,.3,5,.8,.9,1.2,"#e8e0f0","#8a7aa8","none",[]),
 ("cloud_slime","blob","hostile",0,16,.2,3,.9,.9,1,"#f0f8ff","#a8d8ff","none",[]),
 ("gilded_sentinel","biped","hostile",0,60,.22,9,.8,2.2,1.2,"#e8c34a","#fff3a8","horns",[]),
 ("heaven_warden","biped","hostile",0,160,.24,16,1.5,3.4,1.8,"#fff3c4","#d9a82e","halo",["attack"]),
 ("archangel_boss","biped_winged","hostile",1,300,.35,18,1.2,3,1.6,"#ffffff","#ffd34d","halo",[]),
]
assert len(E) == 43, len(E)
EYE = [60, 60]
def cu(o, s, uv): return {"origin": o, "size": s, "uv": uv}
def bn(name, pivot, cubes): return {"name": name, "pivot": pivot, "cubes": cubes}
def eyes(y, z, half): return [cu([-half - .75, y, z], [1.5, 1.5, .4], EYE), cu([half - .75, y, z], [1.5, 1.5, .4], EYE)]
def accents(kind, top, half, zc):
    A = [32, 0]
    if kind == "horns": return [cu([-half, top, zc - .5], [1, 3, 1], A), cu([half - 1, top, zc - .5], [1, 3, 1], A)]
    if kind == "ears": return [cu([-half - 1, top - 2, zc - .5], [1, 4, 2], A), cu([half, top - 2, zc - .5], [1, 4, 2], A)]
    if kind == "halo": return [cu([-half + .5, top + 1, zc - half + .5], [2 * half - 1, 1, 2 * half - 1], A)]
    if kind == "spikes": return [cu([-1, top, zc - 1], [2, 4, 2], A)]
    return []

def geo_bones(arch, acc):
    A = [32, 0]
    if arch in ("biped", "biped_winged"):
        b = [bn("body", [0, 12, 0], [cu([-4, 12, -2], [8, 12, 4], [0, 16])]),
             bn("head", [0, 24, 0], [cu([-4, 24, -4], [8, 8, 8], [0, 0])] + eyes(27, -4.2, 2) + accents(acc, 32, 4, 0)),
             bn("arm_l", [6, 23, 0], [cu([4, 12, -2], [4, 12, 4], [0, 0])]), bn("arm_r", [-6, 23, 0], [cu([-8, 12, -2], [4, 12, 4], [0, 0])]),
             bn("leg_l", [2, 12, 0], [cu([0, 0, -2], [4, 12, 4], [0, 0])]), bn("leg_r", [-2, 12, 0], [cu([-4, 0, -2], [4, 12, 4], [0, 0])])]
        if arch == "biped_winged":
            b += [bn("wing_l", [3, 22, 2], [cu([3, 10, 2], [1, 14, 6], A)]), bn("wing_r", [-3, 22, 2], [cu([-4, 10, 2], [1, 14, 6], A)])]
        return b
    if arch in ("quad", "winged_quad"):
        b = [bn("body", [0, 9, 0], [cu([-3, 6, -4], [6, 6, 8], [0, 16])]),
             bn("head", [0, 11, -4], [cu([-3, 8, -9], [6, 6, 6], [0, 0])] + eyes(11, -9.2, 1.5) + accents(acc, 14, 3, -6))]
        for nm, x, z in (("leg_fl", -2, -3), ("leg_fr", 2, -3), ("leg_bl", -2, 3), ("leg_br", 2, 3)):
            b.append(bn(nm, [x, 6, z], [cu([x - 1, 0, z - 1], [2, 6, 2], [0, 0])]))
        if acc == "tail": b.append(bn("tail", [0, 10, 4], [cu([-1, 8, 4], [2, 2, 6], A)]))
        if acc == "shell": b.append(bn("shell", [0, 12, 0], [cu([-3.5, 12, -4.5], [7, 3, 9], A)]))
        if arch == "winged_quad":
            b += [bn("wing_l", [3, 12, 0], [cu([3, 11.5, -3], [9, 1, 6], A)]), bn("wing_r", [-3, 12, 0], [cu([-12, 11.5, -3], [9, 1, 6], A)])]
        return b
    if arch == "flyer":
        return [bn("body", [0, 7, 0], [cu([-3, 4, -4], [6, 6, 8], [0, 16])]),
                bn("head", [0, 8, -4], [cu([-2.5, 8, -8.5], [5, 5, 5], [0, 0])] + eyes(10.5, -8.7, 1.2) + accents(acc, 13, 2.5, -6)),
                bn("wing_l", [3, 9, 0], [cu([3, 8.5, -3], [10, 1, 6], A)]), bn("wing_r", [-3, 9, 0], [cu([-13, 8.5, -3], [10, 1, 6], A)]),
                bn("tail", [0, 6, 4], [cu([-1, 5, 4], [2, 1, 6], A)])]
    if arch == "blob":
        return [bn("core", [0, 6, 0], [cu([-4, 2, -4], [8, 8, 8], [0, 0])] + eyes(7, -4.2, 2)),
                bn("orb_l", [8, 6, 0], [cu([6.5, 4.5, -1.5], [3, 3, 3], A)]), bn("orb_r", [-8, 6, 0], [cu([-9.5, 4.5, -1.5], [3, 3, 3], A)])]
    if arch == "serpent":
        return [bn("head", [0, 3, -6], [cu([-3, 0, -9], [6, 6, 6], [0, 0])] + eyes(3.5, -9.2, 2) + accents(acc, 6, 3, -6)),
                bn("seg1", [0, 3, 0], [cu([-2.5, .5, -3], [5, 5, 6], [0, 16])]), bn("seg2", [0, 3, 6], [cu([-2, 1, 3], [4, 4, 6], [0, 16])]),
                bn("seg3", [0, 3, 12], [cu([-1.5, 1.5, 9], [3, 3, 6], [0, 16])]), bn("tail", [0, 3, 18], [cu([-1, 2, 15], [2, 2, 6], A)])]

def kf(times, vals): return {("%.2f" % t): v for t, v in zip(times, vals)}
def anim(length, loop, bones): return {"loop": loop, "animation_length": length, "bones": bones}

def build_anim(kind, arch, names):
    B_ = {}
    def has(*n): return all(x in names for x in n)
    def R(bone, times, vals):
        if bone in names: B_.setdefault(bone, {})["rotation"] = kf(times, vals)
    def P(bone, times, vals):
        if bone in names: B_.setdefault(bone, {})["position"] = kf(times, vals)
    if kind == "idle":
        T = [0, 1, 2]
        P("body", T, [[0, 0, 0], [0, .5, 0], [0, 0, 0]]); P("core", T, [[0, 0, 0], [0, 1.5, 0], [0, 0, 0]])
        R("head", T, [[0, 0, 0], [3, 0, 0], [0, 0, 0]]); R("tail", T, [[0, 0, -8], [0, 0, 8], [0, 0, -8]])
        R("arm_l", T, [[0, 0, 0], [5, 0, 0], [0, 0, 0]]); R("arm_r", T, [[0, 0, 0], [-5, 0, 0], [0, 0, 0]])
        R("wing_l", T, [[0, 0, 0], [0, 0, -8], [0, 0, 0]]); R("wing_r", T, [[0, 0, 0], [0, 0, 8], [0, 0, 0]])
        R("orb_l", [0, 2, 4], [[0, 0, 0], [0, 180, 0], [0, 360, 0]]); R("orb_r", [0, 2, 4], [[0, 0, 0], [0, -180, 0], [0, -360, 0]])
        for i, s in enumerate(("seg1", "seg2", "seg3", "tail")): R(s, T, [[0, -8 * (i + 1) / 2, 0], [0, 8 * (i + 1) / 2, 0], [0, -8 * (i + 1) / 2, 0]])
        R("head", T, [[0, 0, 0], [3, 0, 0], [0, 0, 0]])
        return anim(2.0, True, B_)
    if kind == "walk":
        T = [0, .5, 1]
        for a, b_ in (("leg_l", "leg_r"), ("leg_fl", "leg_br"), ("leg_fr", "leg_bl"), ("arm_l", "arm_r")):
            s = 30 if a.startswith("leg") else -25
            R(a, T, [[s, 0, 0], [-s, 0, 0], [s, 0, 0]]); R(b_, T, [[-s, 0, 0], [s, 0, 0], [-s, 0, 0]])
        P("body", [0, .25, .5, .75, 1], [[0, 0, 0], [0, .4, 0], [0, 0, 0], [0, .4, 0], [0, 0, 0]])
        return anim(1.0, True, B_)
    if kind == "fly":
        T = [0, .25, .5]
        R("wing_l", T, [[0, 0, 35], [0, 0, -35], [0, 0, 35]]); R("wing_r", T, [[0, 0, -35], [0, 0, 35], [0, 0, -35]])
        P("body", T, [[0, 0, 0], [0, 1, 0], [0, 0, 0]]); R("tail", T, [[10, 0, 0], [-10, 0, 0], [10, 0, 0]])
        return anim(.5, True, B_)
    if kind == "attack":
        T = [0, .2, .35, .6]
        R("arm_l", T, [[0, 0, 0], [-100, 0, 0], [-30, 0, 0], [0, 0, 0]]); R("arm_r", T, [[0, 0, 0], [-100, 0, 0], [-30, 0, 0], [0, 0, 0]])
        R("head", T, [[0, 0, 0], [-20, 0, 0], [15, 0, 0], [0, 0, 0]])
        if arch in ("quad", "serpent"): P("head", T, [[0, 0, 0], [0, 0, 1], [0, 0, -4], [0, 0, 0]])
        return anim(.6, False, B_)

TOTAL_ANIMS = 0
EDEFS = []
for (n, arch, beh, fl, hp, sp, dmg, wd, ht, sc, base, acc_hex, acc, extras) in E:
    bones = geo_bones(arch, acc)
    names = {b_["name"] for b_ in bones}
    _seed = zlib.crc32(n.encode())
    px = pack_and_paint(bones, base, acc_hex, beh == "hostile", _seed)
    w(ASSETS + "/geo/entity/" + n + ".geo.json", {"format_version": "1.12.0", "minecraft:geometry": [{
        "description": {"identifier": "geometry.heaven." + n, "texture_width": 128, "texture_height": 128,
            "visible_bounds_width": 4, "visible_bounds_height": 4, "visible_bounds_offset": [0, 1, 0]}, "bones": bones}]})
    anims = {}
    for k in ["idle"] + extras:
        anims["animation." + n + "." + k] = build_anim(k, arch, names)
    TOTAL_ANIMS += len(anims)
    w(ASSETS + "/animations/entity/" + n + ".animation.json", {"format_version": "1.8.0", "animations": anims})
    save_png(ASSETS + "/textures/entity/" + n + ".png", px)
    LANG["entity." + MOD + "." + n] = title(n)
    EDEFS.append(dict(name=n, behavior=beh, flying=bool(fl), hp=hp, speed=sp, damage=dmg, width=wd, height=ht, scale=sc,
                      anims=["idle"] + extras, egg=[int(base.lstrip("#"), 16), int(acc_hex.lstrip("#"), 16)]))
    I(n + "_spawn_egg", "spawn_egg", entity=n, color1=int(base.lstrip("#"), 16), color2=int(acc_hex.lstrip("#"), 16))
    LANG["item." + MOD + "." + n + "_spawn_egg"] = title(n) + " Spawn Egg"
    item_model(n + "_spawn_egg", "minecraft:item/template_spawn_egg")
assert TOTAL_ANIMS == 64, TOTAL_ANIMS

# ---------------------------------------------------------------- write defs, lang, loot, recipes, tags
ARMOR_DEFS = {m: dict(boots=a["b"], leggings=a["l"], chestplate=a["c"], helmet=a["h"], durability=a["dur"], toughness=a["tough"],
                      knockback=a["kb"], enchant=a["ench"], repair=a["repair"]) for m, a in ARM.items()}
w(RES + "/heaven_defs.json", {"blocks": BLOCKS, "items": ITEMS, "tool_materials": TOOL_MATS, "armor_materials": ARMOR_DEFS, "entities": EDEFS})
for k, v in LOOT.items(): w(DATA + "/loot_table/blocks/" + k + ".json", v)
for k, v in RECIPES.items(): w(DATA + "/recipe/" + k + ".json", v)
def tagfile(path, names, ns=MOD):
    w(path, {"replace": False, "values": [ns + ":" + n for n in names]})
tagfile(RES + "/data/minecraft/tags/block/mineable/pickaxe.json", TAGS["pickaxe"])
tagfile(RES + "/data/minecraft/tags/block/mineable/axe.json", TAGS["axe"])
tagfile(RES + "/data/minecraft/tags/block/mineable/hoe.json", TAGS["hoe"])
tagfile(RES + "/data/minecraft/tags/block/mineable/shovel.json", ["cloud_dirt", "cloud_grass"])
tagfile(RES + "/data/minecraft/tags/block/logs.json", TAGS["logs"])
tagfile(RES + "/data/minecraft/tags/block/leaves.json", TAGS["leaves"])
tagfile(RES + "/data/minecraft/tags/block/dirt.json", TAGS["dirt"])
tagfile(RES + "/data/minecraft/tags/block/small_flowers.json", list(FLOWERS))

# ---------------------------------------------------------------- DIMENSION + WORLDGEN
w(DATA + "/dimension_type/heaven.json", {"ultrawarm": False, "natural": True, "coordinate_scale": 1.0, "has_skylight": True, "has_ceiling": False,
    "ambient_light": 0.2, "fixed_time": 6000, "monster_spawn_light_level": 15, "monster_spawn_block_light_limit": 15, "piglin_safe": False,
    "bed_works": True, "respawn_anchor_works": False, "has_raids": False, "logical_height": 128, "min_y": 0, "height": 128,
    "infiniburn": "#minecraft:infiniburn_overworld", "effects": "minecraft:overworld"})

def noise_fn(noise, xz, y): return {"type": "minecraft:noise", "noise": noise, "xz_scale": xz, "y_scale": y}
def grad(y0, y1, v0, v1): return {"type": "minecraft:y_clamped_gradient", "from_y": y0, "to_y": y1, "from_value": v0, "to_value": v1}
def add(a, b): return {"type": "minecraft:add", "argument1": a, "argument2": b}
def mul(a, b): return {"type": "minecraft:mul", "argument1": a, "argument2": b}
top = add(grad(40, 85, 1.5, -1.5), mul(0.9, noise_fn("minecraft:jagged", 0.25, 0.4)))
bottom = add(grad(20, 50, -1.5, 1.5), mul(1.6, noise_fn("minecraft:gravel", 0.06, 0)))
final_density = {"type": "minecraft:interpolated", "argument": {"type": "minecraft:min", "argument1": top, "argument2": bottom}}
cs = {"Name": MOD + ":cloud_stone"}
surface = {"type": "minecraft:sequence", "sequence": [
    {"type": "minecraft:condition", "if_true": {"type": "minecraft:stone_depth", "offset": 0, "surface_type": "floor", "add_surface_depth": False, "secondary_depth_range": 0},
     "then_run": {"type": "minecraft:block", "result_state": {"Name": MOD + ":cloud_grass"}}},
    {"type": "minecraft:condition", "if_true": {"type": "minecraft:stone_depth", "offset": 0, "surface_type": "floor", "add_surface_depth": True, "secondary_depth_range": 0},
     "then_run": {"type": "minecraft:block", "result_state": {"Name": MOD + ":cloud_dirt"}}}]}
router = {k: 0 for k in ("barrier", "fluid_level_floodedness", "fluid_level_spread", "lava", "continents", "erosion", "depth", "ridges",
                          "initial_density_without_jaggedness", "vein_toggle", "vein_ridged", "vein_gap")}
router["temperature"] = mul(2.0, noise_fn("minecraft:temperature", 0.4, 0))
router["vegetation"] = mul(2.0, noise_fn("minecraft:vegetation", 0.4, 0))
router["final_density"] = final_density
w(DATA + "/worldgen/noise_settings/heaven.json", {"sea_level": 0, "disable_mob_generation": False, "aquifers_enabled": False, "ore_veins_enabled": False,
    "legacy_random_source": False, "default_block": cs, "default_fluid": {"Name": "minecraft:air"},
    "noise": {"min_y": 0, "height": 128, "size_horizontal": 2, "size_vertical": 2}, "noise_router": router, "spawn_target": [], "surface_rule": surface})

biomes = [("heaven_meadow", [-2, 0], [-2, 0], 0x9AD5FF, ["aurora_wood"], ["sky_lily", "star_daisy", "pearl_bloom"]),
          ("cloud_forest", [-2, 0], [0, 2], 0xB9E3FF, ["halo_wood", "aurora_wood"], ["zephyr_fern", "azure_bell", "opal_iris"]),
          ("golden_peaks", [0, 2], [-2, 0], 0xFFE6A0, ["halo_wood"], ["halo_rose", "sun_poppy", "gilded_marigold"]),
          ("crystal_gardens", [0, 2], [0, 2], 0xE0C8FF, ["pearl_wood"], ["aurora_orchid", "lumen_lotus", "dawn_tulip"])]

ore_ids = []
for m in GEMS:
    w(DATA + "/worldgen/configured_feature/ore_" + m + ".json", {"type": "minecraft:ore", "config": {"size": 7, "discard_chance_on_air_exposure": 0.0,
        "targets": [{"target": {"predicate_type": "minecraft:block_match", "block": MOD + ":cloud_stone"}, "state": {"Name": MOD + ":" + m + "_ore"}}]}})
    w(DATA + "/worldgen/placed_feature/ore_" + m + ".json", {"feature": MOD + ":ore_" + m, "placement": [
        {"type": "minecraft:count", "count": 6}, {"type": "minecraft:in_square"},
        {"type": "minecraft:height_range", "height": {"type": "uniform", "min_inclusive": {"absolute": 20}, "max_inclusive": {"absolute": 80}}},
        {"type": "minecraft:biome"}]})
    ore_ids.append(MOD + ":ore_" + m)

def simple(name): return {"type": "minecraft:simple_state_provider", "state": {"Name": MOD + ":" + name}}
for wn, (lg, pl, lf) in WOODS.items():
    w(DATA + "/worldgen/configured_feature/tree_" + wn + ".json", {"type": "minecraft:tree", "config": {
        "trunk_provider": {"type": "minecraft:simple_state_provider", "state": {"Name": MOD + ":" + wn + "_log", "Properties": {"axis": "y"}}},
        "foliage_provider": {"type": "minecraft:simple_state_provider", "state": {"Name": MOD + ":" + wn + "_leaves", "Properties": {"distance": "7", "persistent": "false"}}},
        "trunk_placer": {"type": "minecraft:straight_trunk_placer", "base_height": 5, "height_rand_a": 3, "height_rand_b": 0},
        "foliage_placer": {"type": "minecraft:blob_foliage_placer", "radius": 2, "offset": 0, "height": 3},
        "minimum_size": {"type": "minecraft:two_layers_feature_size", "limit": 1, "lower_size": 0, "upper_size": 1},
        "dirt_provider": simple("cloud_dirt"), "ignore_vines": True}})
    w(DATA + "/worldgen/placed_feature/tree_" + wn + ".json", {"feature": MOD + ":tree_" + wn, "placement": [
        {"type": "minecraft:count", "count": 3}, {"type": "minecraft:in_square"}, {"type": "minecraft:heightmap", "heightmap": "OCEAN_FLOOR_WG"},
        {"type": "minecraft:block_predicate_filter", "predicate": {"type": "minecraft:matching_blocks", "offset": [0, -1, 0], "blocks": MOD + ":cloud_grass"}},
        {"type": "minecraft:biome"}]})
for f in FLOWERS:
    w(DATA + "/worldgen/configured_feature/patch_" + f + ".json", {"type": "minecraft:random_patch", "config": {"tries": 20, "xz_spread": 6, "y_spread": 2,
        "feature": {"feature": {"type": "minecraft:simple_block", "config": {"to_place": simple(f)}}, "placement": [
            {"type": "minecraft:block_predicate_filter", "predicate": {"type": "minecraft:all_of", "predicates": [
                {"type": "minecraft:matching_blocks", "blocks": "minecraft:air"},
                {"type": "minecraft:matching_blocks", "offset": [0, -1, 0], "blocks": MOD + ":cloud_grass"}]}}]}}})
    w(DATA + "/worldgen/placed_feature/patch_" + f + ".json", {"feature": MOD + ":patch_" + f, "placement": [
        {"type": "minecraft:rarity_filter", "chance": 3}, {"type": "minecraft:in_square"}, {"type": "minecraft:heightmap", "heightmap": "MOTION_BLOCKING"},
        {"type": "minecraft:biome"}]})

for (bn_, t, h, sky, trees, flw) in biomes:
    feats = [[] for _ in range(11)]
    feats[6] = [o.replace(":ore_", ":ore_") for o in ore_ids]
    feats[9] = [MOD + ":tree_" + x for x in trees] + [MOD + ":patch_" + x for x in flw]
    w(DATA + "/worldgen/biome/" + bn_ + ".json", {"has_precipitation": False, "temperature": 0.8, "downfall": 0.0,
        "effects": {"sky_color": sky, "fog_color": 0xE8F4FF, "water_color": 0x7FD6FF, "water_fog_color": 0x2A6FA0},
        "spawners": {k: [] for k in ("monster", "creature", "ambient", "axolotls", "underground_water_creature", "water_creature", "water_ambient", "misc")},
        "spawn_costs": {}, "carvers": [], "features": feats})
    LANG["biome." + MOD + "." + bn_] = title(bn_)
w(DATA + "/dimension/heaven.json", {"type": MOD + ":heaven", "generator": {"type": "minecraft:noise", "settings": MOD + ":heaven",
    "biome_source": {"type": "minecraft:multi_noise", "biomes": [{"biome": MOD + ":" + b[0], "parameters": {
        "temperature": b[1], "humidity": b[2], "continentalness": [-2, 2], "erosion": [-2, 2], "depth": [-2, 2], "weirdness": [-2, 2], "offset": 0}} for b in biomes]}}})
LANG["itemGroup." + MOD] = "Heaven Dimension"

# ---------------------------------------------------------------- ADVANCEMENTS
ADV = []
def adv(id_, parent, icon, frame, criteria, req=None, bg=False):
    ADV.append(id_)
    d = {"display": {"icon": {"id": MOD + ":" + icon if ":" not in icon else icon}, "title": {"translate": "advancement.%s.%s.title" % (MOD, id_)},
         "description": {"translate": "advancement.%s.%s.desc" % (MOD, id_)}, "frame": frame, "show_toast": True, "announce_to_chat": True, "hidden": False},
         "criteria": criteria, "requirements": req or [[k] for k in criteria]}
    if bg: d["display"]["background"] = "minecraft:textures/gui/advancements/backgrounds/adventure.png"
    if parent: d["parent"] = MOD + ":" + parent
    w(DATA + "/advancement/" + id_ + ".json", d)
def have(*items): return {("has_" + i.split(":")[-1]): {"trigger": "minecraft:inventory_changed", "conditions": {"items": [{"items": [i if ":" in i else MOD + ":" + i]}]}} for i in items}
def kill(e): return {"kill": {"trigger": "minecraft:player_killed_entity", "conditions": {"entity": [{"condition": "minecraft:entity_properties", "entity": "this", "predicate": {"type": MOD + ":" + e}}]}}}
def dim(d): return {"dim": {"trigger": "minecraft:changed_dimension", "conditions": {"to": d}}}
def eat(i): return {"eat": {"trigger": "minecraft:consume_item", "conditions": {"item": {"items": [MOD + ":" + i]}}}}
def T(id_, t, d): LANG["advancement.%s.%s.title" % (MOD, id_)] = t; LANG["advancement.%s.%s.desc" % (MOD, id_)] = d

adv("root", None, "cloud_key", "task", have("cloud_key"), bg=True); T("root", "Stairway to Heaven", "Craft a Cloud Key")
adv("enter_heaven", "root", "cloud_grass", "task", dim(MOD + ":heaven")); T("enter_heaven", "Above the Clouds", "Enter the Heaven dimension")
adv("return_home", "enter_heaven", "minecraft:grass_block", "task", dim("minecraft:overworld")); T("return_home", "Back to Earth", "Return to the Overworld")
adv("cloud_collector", "enter_heaven", "cloud_stone", "task", have("cloud_stone")); T("cloud_collector", "Cloud Collector", "Mine a Cloud Stone")
adv("heaven_timber", "enter_heaven", "halo_wood_log", "task", have("halo_wood_log")); T("heaven_timber", "Heavenly Timber", "Chop down a Halo Wood tree")
for m, (kind, hx) in GEMS.items():
    adv("collect_" + m, "cloud_collector", m, "task", have(m)); T("collect_" + m, "Collect " + title(m), "Obtain " + title(m))
adv("gold_tools", "collect_halo_gold", "halo_gold_sword", "task", have("halo_gold_sword")); T("gold_tools", "Blessed Blade", "Craft a Halo Gold Sword")
adv("celestial_tools", "collect_celestial_gem", "celestial_gem_pickaxe", "goal", have("celestial_gem_pickaxe")); T("celestial_tools", "Star Miner", "Craft a Celestial Gem Pickaxe")
adv("divine_tools", "collect_divinium", "divinium_sword", "challenge", have("divinium_sword")); T("divine_tools", "Weapon of the Gods", "Craft a Divinium Sword")
adv("feather_armor", "enter_heaven", "feather_chestplate", "task", have(*["feather_" + s for s in APAT])); T("feather_armor", "Light as a Feather", "Wear a full Feather armor set")
adv("seraph_armor", "collect_seraphite", "seraphite_chestplate", "goal", have(*["seraphite_" + s for s in APAT])); T("seraph_armor", "Seraph's Embrace", "Obtain a full Seraphite armor set")
adv("divine_armor", "collect_divinium", "divinium_helmet", "challenge", have(*["divinium_" + s for s in APAT])); T("divine_armor", "Clad in Divinity", "Obtain a full Divinium armor set")
adv("halo_crown", "enter_heaven", "halo_crown", "goal", have("halo_crown")); T("halo_crown", "Crowned", "Craft a Halo Crown")
adv("eat_ambrosia", "enter_heaven", "ambrosia_apple", "task", eat("ambrosia_apple")); T("eat_ambrosia", "Food of the Gods", "Eat an Ambrosia Apple")
adv("divine_feast", "eat_ambrosia", "divine_feast", "goal", eat("divine_feast")); T("divine_feast", "Divine Feast", "Eat a Divine Feast")
adv("sun_lamp", "enter_heaven", "sun_lamp", "task", have("sun_lamp")); T("sun_lamp", "Let There Be Light", "Craft a Sun Lamp")
adv("flower_power", "enter_heaven", "sky_lily", "task", have("sky_lily", "halo_rose", "star_daisy")); T("flower_power", "Heavenly Garden", "Pick a Sky Lily, Halo Rose and Star Daisy")
for e, fr in (("cloud_serpent", "task"), ("fallen_angel", "task"), ("wrath_golem", "goal"), ("heaven_warden", "goal"), ("archangel_boss", "challenge"),
              ("storm_hawk", "task"), ("shadow_wraith", "task"), ("crystal_spider", "task"), ("gilded_sentinel", "task"), ("tempest_wyrm", "goal"),
              ("void_seraph", "goal")):
    adv("slay_" + e, "enter_heaven", e + "_spawn_egg", fr, kill(e)); T("slay_" + e, "Slayer: " + title(e), "Defeat a " + title(e))

# ---------------------------------------------------------------- lang
w(ASSETS + "/lang/en_us.json", dict(sorted(LANG.items())))

print("blocks", len(BLOCKS), "items(non-block)", len(ITEMS), "entities", len(EDEFS), "animations", TOTAL_ANIMS,
      "armor", sum(1 for i in ITEMS if i["kind"] == "armor"), "advancements", len(ADV), "tools", sum(1 for i in ITEMS if i["kind"] == "tool"))
