package com.heavenmod;

import net.minecraft.block.Block;
import net.minecraft.item.ToolMaterial;
import net.minecraft.recipe.Ingredient;
import net.minecraft.registry.Registries;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.util.Identifier;

public record HeavenToolMaterial(int level, int durability, float speed, float damage, int enchant, String repair) implements ToolMaterial {
    @Override public int getDurability() { return durability; }
    @Override public float getMiningSpeedMultiplier() { return speed; }
    @Override public float getAttackDamage() { return damage; }
    @Override public int getEnchantability() { return enchant; }
    @Override public TagKey<Block> getInverseTag() {
        return switch (level) {
            case 0 -> BlockTags.INCORRECT_FOR_WOODEN_TOOL;
            case 1 -> BlockTags.INCORRECT_FOR_STONE_TOOL;
            case 2 -> BlockTags.INCORRECT_FOR_IRON_TOOL;
            case 3 -> BlockTags.INCORRECT_FOR_DIAMOND_TOOL;
            default -> BlockTags.INCORRECT_FOR_NETHERITE_TOOL;
        };
    }
    @Override public Ingredient getRepairIngredient() {
        return Ingredient.ofItems(Registries.ITEM.get(Identifier.of(repair.contains(":") ? repair : HeavenMod.MOD_ID + ":" + repair)));
    }
}
