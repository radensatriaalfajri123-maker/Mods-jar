package com.heavenmod;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.entity.SpawnLocationTypes;
import net.minecraft.entity.SpawnRestriction;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.world.Heightmap;
import net.minecraft.world.biome.Biome;

import java.util.*;

public final class HeavenEntities {
    public static final Map<String, EntityType<HeavenCreature>> TYPES = new LinkedHashMap<>();
    public static final Map<EntityType<?>, EntityDef> DEFS = new HashMap<>();
    public static final List<EntityDef> LIST = new ArrayList<>();
    private HeavenEntities() {}

    public static void register(JsonArray arr) {
        for (JsonElement e : arr) {
            JsonObject o = e.getAsJsonObject();
            Set<String> anims = new LinkedHashSet<>();
            o.getAsJsonArray("anims").forEach(a -> anims.add(a.getAsString()));
            EntityDef d = new EntityDef(o.get("name").getAsString(), o.get("behavior").getAsString(), o.get("flying").getAsBoolean(),
                    o.get("hp").getAsDouble(), o.get("speed").getAsDouble(), o.get("damage").getAsDouble(),
                    o.get("width").getAsFloat(), o.get("height").getAsFloat(), o.get("scale").getAsFloat(), anims,
                    o.getAsJsonArray("egg").get(0).getAsInt(), o.getAsJsonArray("egg").get(1).getAsInt());
            SpawnGroup group = d.hostile() ? SpawnGroup.MONSTER : SpawnGroup.CREATURE;
            EntityType<HeavenCreature> type = Registry.register(Registries.ENTITY_TYPE, HeavenMod.id(d.name()),
                    EntityType.Builder.create(HeavenCreature::new, group)
                            .dimensions(d.width(), d.height()).maxTrackingRange(10).build(d.name()));
            TYPES.put(d.name(), type);
            DEFS.put(type, d);
            LIST.add(d);
            FabricDefaultAttributeRegistry.register(type, HeavenCreature.attributes(d));
        }
    }

    public static void registerSpawns() {
        List<RegistryKey<Biome>> keys = new ArrayList<>();
        for (String b : List.of("heaven_meadow", "cloud_forest", "golden_peaks", "crystal_gardens"))
            keys.add(RegistryKey.of(RegistryKeys.BIOME, HeavenMod.id(b)));
        for (EntityDef d : LIST) {
            EntityType<HeavenCreature> type = TYPES.get(d.name());
            boolean boss = d.hp() >= 150;
            SpawnGroup group = d.hostile() ? SpawnGroup.MONSTER : SpawnGroup.CREATURE;
            int weight = boss ? 1 : d.hostile() ? 8 : 10;
            BiomeModifications.addSpawn(BiomeSelectors.includeByKey(keys), group, type, weight, 1, boss ? 1 : 3);
            SpawnRestriction.register(type, d.flying() ? SpawnLocationTypes.UNRESTRICTED : SpawnLocationTypes.ON_GROUND,
                    Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, (t, w, spawnReason, pos, rnd) -> true);
        }
    }
}
