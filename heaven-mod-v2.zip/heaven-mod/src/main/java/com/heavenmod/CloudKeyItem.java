package com.heavenmod;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

/** Right-click: Overworld -> Heaven, Heaven -> Overworld. */
public class CloudKeyItem extends Item {
    public CloudKeyItem(Settings settings) { super(settings); }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity player, Hand hand) {
        ItemStack stack = player.getStackInHand(hand);
        if (!world.isClient && player instanceof ServerPlayerEntity sp && sp.getServer() != null) {
            boolean inHeaven = world.getRegistryKey().equals(HeavenDimension.WORLD);
            ServerWorld target = sp.getServer().getWorld(inHeaven ? World.OVERWORLD : HeavenDimension.WORLD);
            if (target == null) return TypedActionResult.fail(stack);
            HeavenDimension.teleport(sp, target, inHeaven);
            player.getItemCooldownManager().set(this, 60);
        }
        return TypedActionResult.success(stack, world.isClient);
    }
}
