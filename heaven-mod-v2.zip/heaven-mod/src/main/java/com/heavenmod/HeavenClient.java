package com.heavenmod;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap;
import net.fabricmc.fabric.api.client.rendering.v1.ColorProviderRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.item.SpawnEggItem;

public class HeavenClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        for (EntityDef d : HeavenEntities.LIST) {
            EntityRendererRegistry.register(HeavenEntities.TYPES.get(d.name()),
                    ctx -> new HeavenCreatureRenderer(ctx, d.name(), d.scale()));
            if (HeavenItems.ITEMS.get(d.name() + "_spawn_egg") instanceof SpawnEggItem egg) {
                ColorProviderRegistry.ITEM.register((stack, tint) -> 0xFF000000 | egg.getColor(tint), egg);
            }
        }
        HeavenBlocks.KINDS.forEach((name, kind) -> {
            var block = HeavenBlocks.BLOCKS.get(name);
            switch (kind) {
                case "leaves" -> BlockRenderLayerMap.INSTANCE.putBlock(block, RenderLayer.getCutoutMipped());
                case "plant" -> BlockRenderLayerMap.INSTANCE.putBlock(block, RenderLayer.getCutout());
                case "glass" -> BlockRenderLayerMap.INSTANCE.putBlock(block, RenderLayer.getTranslucent());
                default -> { }
            }
        });
    }
}
