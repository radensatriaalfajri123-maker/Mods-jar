package com.heavenmod;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.ai.control.FlightMoveControl;
import net.minecraft.entity.ai.goal.*;
import net.minecraft.entity.ai.pathing.BirdNavigation;
import net.minecraft.entity.ai.pathing.EntityNavigation;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.mob.PathAwareEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.world.World;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.animation.*;
import software.bernie.geckolib.util.GeckoLibUtil;

/** One generic, data-driven creature class used by all 43 Heaven entities. */
public class HeavenCreature extends PathAwareEntity implements GeoEntity {
    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);

    public HeavenCreature(EntityType<? extends HeavenCreature> type, World world) {
        super(type, world);
        EntityDef d = def();
        if (d != null && d.flying()) {
            this.moveControl = new FlightMoveControl(this, 20, true);
        }
    }

    public EntityDef def() { return HeavenEntities.DEFS.get(getType()); }

    public static DefaultAttributeContainer.Builder attributes(EntityDef d) {
        return MobEntity.createMobAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, d.hp())
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, d.speed())
                .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, Math.max(d.damage(), 0.5))
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 32.0)
                .add(EntityAttributes.GENERIC_FLYING_SPEED, d.speed() * 1.5);
    }

    @Override
    protected EntityNavigation createNavigation(World world) {
        EntityDef d = def();
        if (d != null && d.flying()) {
            BirdNavigation nav = new BirdNavigation(this, world);
            nav.setCanPathThroughDoors(false);
            nav.setCanSwim(true);
            nav.setCanEnterOpenDoors(true);
            return nav;
        }
        return super.createNavigation(world);
    }

    @Override
    protected void initGoals() {
        EntityDef d = def();
        boolean fly = d.flying();
        goalSelector.add(0, new SwimGoal(this));
        if (d.passive()) goalSelector.add(1, new EscapeDangerGoal(this, 1.4));
        if (!d.passive()) goalSelector.add(2, new MeleeAttackGoal(this, 1.2, false));
        goalSelector.add(5, fly ? new FlyGoal(this, 1.0) : new WanderAroundFarGoal(this, 1.0));
        goalSelector.add(6, new LookAtEntityGoal(this, PlayerEntity.class, 8.0f));
        goalSelector.add(7, new LookAroundGoal(this));
        if (d.hostile()) {
            targetSelector.add(1, new RevengeGoal(this));
            targetSelector.add(2, new ActiveTargetGoal<>(this, PlayerEntity.class, true));
        } else if (d.neutral()) {
            targetSelector.add(1, new RevengeGoal(this));
        }
    }

    @Override
    public boolean handleFallDamage(float fallDistance, float damageMultiplier, DamageSource source) {
        return !def().flying() && super.handleFallDamage(fallDistance, damageMultiplier, source);
    }

    // ---- GeckoLib ----
    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<>(this, "main", 5, this::predicate));
    }

    private String anim(String n) { return "animation." + def().name() + "." + n; }

    private PlayState predicate(AnimationState<HeavenCreature> state) {
        EntityDef d = def();
        if (d.anims().contains("attack") && this.handSwinging
                && state.getController().getAnimationState() == AnimationController.State.STOPPED) {
            state.getController().forceAnimationReset();
            return state.setAndContinue(RawAnimation.begin().then(anim("attack"), Animation.LoopType.PLAY_ONCE));
        }
        if (state.isMoving()) {
            if (d.flying() && d.anims().contains("fly")) return state.setAndContinue(RawAnimation.begin().thenLoop(anim("fly")));
            if (d.anims().contains("walk")) return state.setAndContinue(RawAnimation.begin().thenLoop(anim("walk")));
            if (d.anims().contains("fly")) return state.setAndContinue(RawAnimation.begin().thenLoop(anim("fly")));
        }
        if (state.getController().getAnimationState() == AnimationController.State.RUNNING
                && state.getController().getCurrentAnimation() != null
                && state.getController().getCurrentAnimation().animation().name().endsWith(".attack")) {
            return PlayState.CONTINUE;
        }
        return state.setAndContinue(RawAnimation.begin().thenLoop(anim("idle")));
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() { return cache; }
}
