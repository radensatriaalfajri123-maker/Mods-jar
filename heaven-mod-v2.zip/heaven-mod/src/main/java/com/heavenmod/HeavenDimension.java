package com.heavenmod;

import net.minecraft.block.Block;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.Heightmap;
import net.minecraft.world.World;

public final class HeavenDimension {
    public static final RegistryKey<World> WORLD = RegistryKey.of(RegistryKeys.WORLD, HeavenMod.id("heaven"));
    private HeavenDimension() {}

    public static void teleport(ServerPlayerEntity p, ServerWorld target, boolean returning) {
        BlockPos pos = returning ? target.getSpawnPos() : p.getBlockPos();
        int x = pos.getX(), z = pos.getZ();
        target.getChunk(x >> 4, z >> 4);
        int y = target.getTopY(Heightmap.Type.MOTION_BLOCKING, x, z);
        if (y <= target.getBottomY() + 2) { // void here: build a small cloud platform
            y = 64;
            Block stone = HeavenBlocks.BLOCKS.get("cloud_stone");
            for (int dx = -2; dx <= 2; dx++)
                for (int dz = -2; dz <= 2; dz++)
                    target.setBlockState(new BlockPos(x + dx, y - 1, z + dz), stone.getDefaultState());
        }
        p.teleport(target, x + 0.5, y, z + 0.5, p.getYaw(), p.getPitch());
    }
}
