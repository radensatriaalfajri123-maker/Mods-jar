package com.heavenmod;

import java.util.Set;

public record EntityDef(String name, String behavior, boolean flying, double hp, double speed, double damage,
                        float width, float height, float scale, Set<String> anims, int egg1, int egg2) {
    public boolean hostile() { return behavior.equals("hostile"); }
    public boolean neutral() { return behavior.equals("neutral"); }
    public boolean passive() { return behavior.equals("passive"); }
}
