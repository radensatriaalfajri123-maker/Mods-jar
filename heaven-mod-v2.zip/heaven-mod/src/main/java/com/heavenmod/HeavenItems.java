package com.heavenmod;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.item.*;
import net.minecraft.recipe.Ingredient;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.Util;

import java.util.EnumMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class HeavenItems {
    public static final Map<String, Item> ITEMS = new LinkedHashMap<>();
    private HeavenItems() {}

    private static Item reg(String name, Item item) {
        Registry.register(Registries.ITEM, HeavenMod.id(name), item);
        ITEMS.put(name, item);
        return item;
    }

    public static void register(JsonObject defs) {
        Map<String, HeavenToolMaterial> tools = new LinkedHashMap<>();
        for (var en : defs.getAsJsonObject("tool_materials").entrySet()) {
            JsonObject t = en.getValue().getAsJsonObject();
            tools.put(en.getKey(), new HeavenToolMaterial(t.get("level").getAsInt(), t.get("durability").getAsInt(),
                    t.get("speed").getAsFloat(), t.get("damage").getAsFloat(), t.get("enchant").getAsInt(), t.get("repair").getAsString()));
        }
        Map<String, RegistryEntry<ArmorMaterial>> armors = new LinkedHashMap<>();
        Map<String, Integer> armorDur = new LinkedHashMap<>();
        for (var en : defs.getAsJsonObject("armor_materials").entrySet()) {
            String m = en.getKey();
            JsonObject a = en.getValue().getAsJsonObject();
            EnumMap<ArmorItem.Type, Integer> def = Util.make(new EnumMap<>(ArmorItem.Type.class), map -> {
                map.put(ArmorItem.Type.BOOTS, a.get("boots").getAsInt());
                map.put(ArmorItem.Type.LEGGINGS, a.get("leggings").getAsInt());
                map.put(ArmorItem.Type.CHESTPLATE, a.get("chestplate").getAsInt());
                map.put(ArmorItem.Type.HELMET, a.get("helmet").getAsInt());
                map.put(ArmorItem.Type.BODY, a.get("chestplate").getAsInt());
            });
            String repair = a.get("repair").getAsString();
            ArmorMaterial mat = new ArmorMaterial(def, a.get("enchant").getAsInt(), SoundEvents.ITEM_ARMOR_EQUIP_IRON,
                    () -> Ingredient.ofItems(Registries.ITEM.get(Identifier.of(repair))),
                    List.of(new ArmorMaterial.Layer(HeavenMod.id(m))),
                    a.get("toughness").getAsFloat(), a.get("knockback").getAsFloat());
            armors.put(m, Registry.registerReference(Registries.ARMOR_MATERIAL, HeavenMod.id(m), mat));
            armorDur.put(m, a.get("durability").getAsInt());
        }

        for (JsonElement e : defs.getAsJsonArray("items")) {
            JsonObject o = e.getAsJsonObject();
            String name = o.get("name").getAsString();
            switch (o.get("kind").getAsString()) {
                case "key" -> reg(name, new CloudKeyItem(new Item.Settings().maxCount(1).rarity(Rarity.EPIC)));
                case "food" -> {
                    FoodComponent.Builder fb = new FoodComponent.Builder()
                            .nutrition(o.get("nutrition").getAsInt()).saturationModifier(o.get("saturation").getAsFloat());
                    if (!o.get("effect").isJsonNull()) {
                        var eff = Registries.STATUS_EFFECT.getEntry(Identifier.of(o.get("effect").getAsString()));
                        eff.ifPresent(h -> fb.statusEffect(new StatusEffectInstance(h, o.get("duration").getAsInt() * 20, o.get("amplifier").getAsInt()), 1.0f));
                        fb.alwaysEdible();
                    }
                    reg(name, new Item(new Item.Settings().food(fb.build())));
                }
                case "tool" -> {
                    HeavenToolMaterial m = tools.get(o.get("material").getAsString());
                    Item.Settings s = new Item.Settings();
                    reg(name, switch (o.get("tool").getAsString()) {
                        case "sword" -> new SwordItem(m, s.attributeModifiers(SwordItem.createAttributeModifiers(m, 3, -2.4f)));
                        case "pickaxe" -> new PickaxeItem(m, s.attributeModifiers(PickaxeItem.createAttributeModifiers(m, 1.0f, -2.8f)));
                        case "axe" -> new AxeItem(m, s.attributeModifiers(AxeItem.createAttributeModifiers(m, 6.0f, -3.1f)));
                        case "shovel" -> new ShovelItem(m, s.attributeModifiers(ShovelItem.createAttributeModifiers(m, 1.5f, -3.0f)));
                        default -> new HoeItem(m, s.attributeModifiers(HoeItem.createAttributeModifiers(m, -m.getAttackDamage(), 0.0f)));
                    });
                }
                case "armor" -> {
                    String mat = o.get("material").getAsString();
                    ArmorItem.Type type = switch (o.get("slot").getAsString()) {
                        case "helmet" -> ArmorItem.Type.HELMET;
                        case "chestplate" -> ArmorItem.Type.CHESTPLATE;
                        case "leggings" -> ArmorItem.Type.LEGGINGS;
                        default -> ArmorItem.Type.BOOTS;
                    };
                    reg(name, new ArmorItem(armors.get(mat), type, new Item.Settings().maxDamage(type.getMaxDamage(armorDur.get(mat)))));
                }
                case "spawn_egg" -> reg(name, new SpawnEggItem(HeavenEntities.TYPES.get(o.get("entity").getAsString()),
                        o.get("color1").getAsInt(), o.get("color2").getAsInt(), new Item.Settings()));
                default -> reg(name, new Item(new Item.Settings()));
            }
        }
    }

    public static void registerTab() {
        Registry.register(Registries.ITEM_GROUP, HeavenMod.id("heaven"), FabricItemGroup.builder()
                .icon(() -> new ItemStack(ITEMS.get("cloud_key")))
                .displayName(Text.translatable("itemGroup.heaven"))
                .entries((ctx, entries) -> {
                    HeavenBlocks.BLOCK_ITEMS.values().forEach(entries::add);
                    ITEMS.values().forEach(entries::add);
                }).build());
    }
}
