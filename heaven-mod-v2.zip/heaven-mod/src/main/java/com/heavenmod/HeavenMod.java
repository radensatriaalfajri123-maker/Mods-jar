package com.heavenmod;

import com.google.gson.JsonObject;
import net.fabricmc.api.ModInitializer;
import net.minecraft.util.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class HeavenMod implements ModInitializer {
    public static final String MOD_ID = "heaven";
    public static final Logger LOG = LoggerFactory.getLogger(MOD_ID);

    public static Identifier id(String path) { return Identifier.of(MOD_ID, path); }

    @Override
    public void onInitialize() {
        JsonObject defs = HeavenDefs.get();
        HeavenBlocks.register(defs.getAsJsonArray("blocks"));
        HeavenEntities.register(defs.getAsJsonArray("entities"));
        HeavenItems.register(defs);
        HeavenItems.registerTab();
        HeavenEntities.registerSpawns();
        LOG.info("Heaven Dimension loaded: {} blocks, {} items, {} entities",
                HeavenBlocks.BLOCKS.size(), HeavenItems.ITEMS.size() + HeavenBlocks.BLOCK_ITEMS.size(), HeavenEntities.TYPES.size());
    }
}
