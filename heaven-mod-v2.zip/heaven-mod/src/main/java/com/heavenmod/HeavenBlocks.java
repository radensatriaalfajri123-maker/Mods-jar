package com.heavenmod;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import net.minecraft.block.*;
import net.minecraft.block.piston.PistonBehavior;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;

import java.util.LinkedHashMap;
import java.util.Map;

public final class HeavenBlocks {
    public static final Map<String, Block> BLOCKS = new LinkedHashMap<>();
    public static final Map<String, Item> BLOCK_ITEMS = new LinkedHashMap<>();
    public static final Map<String, String> KINDS = new LinkedHashMap<>();
    private HeavenBlocks() {}

    private static BlockSoundGroup sound(String s) {
        return switch (s) {
            case "wood" -> BlockSoundGroup.WOOD;
            case "grass" -> BlockSoundGroup.GRASS;
            case "glass" -> BlockSoundGroup.GLASS;
            case "wool" -> BlockSoundGroup.WOOL;
            case "metal" -> BlockSoundGroup.METAL;
            default -> BlockSoundGroup.STONE;
        };
    }

    public static void register(JsonArray arr) {
        for (JsonElement e : arr) {
            JsonObject o = e.getAsJsonObject();
            String name = o.get("name").getAsString();
            String kind = o.get("kind").getAsString();
            final int light = o.get("light").getAsInt();
            AbstractBlock.Settings s = AbstractBlock.Settings.create()
                    .strength(o.get("hardness").getAsFloat(), o.get("resistance").getAsFloat())
                    .sounds(sound(o.get("sound").getAsString()));
            if (light > 0) s = s.luminance(st -> light);

            Block block = switch (kind) {
                case "stairs" -> {
                    Block base = BLOCKS.get(o.get("base").getAsString());
                    yield new StairsBlock(base.getDefaultState(), AbstractBlock.Settings.copy(base));
                }
                case "slab" -> new SlabBlock(s);
                case "pillar" -> new PillarBlock(s);
                case "leaves" -> new LeavesBlock(s.nonOpaque()
                        .allowsSpawning((st, w, p, t) -> false)
                        .suffocates((st, w, p) -> false)
                        .blockVision((st, w, p) -> false));
                case "glass" -> new TransparentBlock(s.nonOpaque()
                        .allowsSpawning((st, w, p, t) -> false)
                        .suffocates((st, w, p) -> false)
                        .blockVision((st, w, p) -> false));
                case "plant" -> new FlowerBlock(StatusEffects.SATURATION, 5.0f, AbstractBlock.Settings.create()
                        .noCollision().breakInstantly().nonOpaque().sounds(BlockSoundGroup.GRASS)
                        .offset(AbstractBlock.OffsetType.XZ).pistonBehavior(PistonBehavior.DESTROY));
                default -> new Block(s);
            };
            Registry.register(Registries.BLOCK, HeavenMod.id(name), block);
            BLOCK_ITEMS.put(name, Registry.register(Registries.ITEM, HeavenMod.id(name), new BlockItem(block, new Item.Settings())));
            BLOCKS.put(name, block);
            KINDS.put(name, kind);
        }
    }
}
