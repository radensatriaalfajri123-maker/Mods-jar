package com.heavenmod;

import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.util.Identifier;
import software.bernie.geckolib.model.DefaultedEntityGeoModel;
import software.bernie.geckolib.renderer.GeoEntityRenderer;

/** Loads geo/entity/<name>.geo.json, animations/entity/<name>.animation.json, textures/entity/<name>.png */
public class HeavenCreatureRenderer extends GeoEntityRenderer<HeavenCreature> {
    public HeavenCreatureRenderer(EntityRendererFactory.Context ctx, String name, float scale) {
        super(ctx, new DefaultedEntityGeoModel<>(Identifier.of(HeavenMod.MOD_ID, name)));
        withScale(scale);
        this.shadowRadius = 0.4f * scale;
    }
}
